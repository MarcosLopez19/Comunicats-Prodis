package cat.copernic.comunicatsprodis.rvAutorizacions.usuari

import android.content.Context
import android.graphics.Color
import android.graphics.Color.green
import android.graphics.Color.red
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.comunicatsprodis.R
import cat.copernic.comunicatsprodis.Utils
import cat.copernic.comunicatsprodis.autoritzacionsUsuariDirections
import cat.copernic.comunicatsprodis.rvAutorizacions.usuari.ProviderUsuari.Companion.missatgeListUsuari
import cat.copernic.comunicatsprodis.databinding.AutoritzacioUsuariItemBinding
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Clase AdapterAutoritzacionsUsuari2 es un adaptador para la lista de mensajes.
 * @param missatge Lista de objetos Missatge que se mostrarán en la vista.
 * @constructor Crea una nueva instancia de AdapterAutoritzacionsUsuari2 con los parámetros especificados.
 * @Implements [RecyclerView.Adapter] para proporcionar un adaptador personalizado para la vista de RecyclerView.
 */
class AdapterAutoritzacionsUsuari2(private val missatge: List<Missatge>) : RecyclerView.Adapter<AdapterAutoritzacionsUsuari2.ViewHolderUsuari>() {

    /**
     * Clase interna que representa un ViewHolder para el diseño del elemento de usuario.
     * @param binding La vinculación para el diseño del elemento de usuario.
     */
    inner class ViewHolderUsuari(val binding: AutoritzacioUsuariItemBinding): RecyclerView.ViewHolder(binding.root)

    private var binding: AutoritzacioUsuariItemBinding? = null
    /**
     * Variable que almacena una instancia de FirebaseFirestore.
     */
    private var bd = FirebaseFirestore.getInstance()

    /**
     * Crea y devuelve un nuevo ViewHolder para el diseño del elemento de usuario.
     * @param parent El ViewGroup padre del nuevo ViewHolder.
     * @param viewType El tipo de vista del nuevo ViewHolder.
     * @return Un nuevo ViewHolder para el diseño del elemento de usuario.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderUsuari {
        val binding= AutoritzacioUsuariItemBinding.inflate(LayoutInflater.from(parent.context),parent, false)
        return ViewHolderUsuari(binding)
    }

    /**
     * Enlaza un ViewHolder existente con un elemento de la lista de usuarios en una posición específica.
     * @param holder El ViewHolder existente que se va a enlazar.
     * @param position La posición del elemento en la lista de usuario.
     */
    override fun onBindViewHolder(holder: ViewHolderUsuari, position: Int) {
        with(holder) {
            with(missatgeListUsuari[position]) {
                binding.itemTvMissatge.text = this.nomMissatge
                binding.itemTvNommissatge.text = this.descripcio
            }

            binding.CardRvAutoritzacions.setOnClickListener { view ->
                iniciarSesion(view, missatge.get(position))
            }
        }
    }

    /**
     * Navega a la pantalla de resultatsAutoritzacions.
     * @param view La vista desde la cual se inicia la sesión.
     * @param datos El objeto de tipo Missatge
     */
    private fun iniciarSesion(view : View, datos: Missatge) {

        val action = autoritzacionsUsuariDirections.actionAutoritzacionsUsuariToConfirmacioAutoritzacio(datos)
        view.findNavController().navigate(action)
    }

    /**
     * Función encargada de obtener la cantidad de elementos en la lista de mensajes.
     * @return un entero que representa la cantidad de elementos en la lista de mensajes.
     */
    override fun getItemCount(): Int = missatge.size

}
