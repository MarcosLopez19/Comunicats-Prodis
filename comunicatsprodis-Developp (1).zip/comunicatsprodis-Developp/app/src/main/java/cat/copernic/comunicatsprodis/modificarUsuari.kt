package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.comunicatsprodis.databinding.FragmentModificarUsuariBinding
import cat.copernic.comunicatsprodis.rvModificarUsuari.AdapterModificarUsuari
import cat.copernic.comunicatsprodis.rvModificarUsuari.MissatgeModificarUsuari
import cat.copernic.comunicatsprodis.rvModificarUsuari.ProviderModificarUsuari
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * En esta clase se modifica un usuari de la base de datos de Firebase.
 */
class modificarUsuari : Fragment() {

    private var _binding: FragmentModificarUsuariBinding? = null
    private val binding get() = _binding!!
    val bd = FirebaseFirestore.getInstance()


    /**
     * Método que se ejecuta al crear la actividad.
     * En este método se obtiene la lista de mensajes de la clase ProviderModificarUsuari.
     * @param savedInstanceState Guarda el estado de la aplicación en caso de cambio de configuración.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ProviderModificarUsuari.missatgeListModificarUsuari
    }
    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autorizaciones de administrador.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentModificarUsuariBinding.inflate(inflater)
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initRecyclerView()
    }

    /**
     * Inicializamos el RecyclerView.
     * Primero limpiamos la lista de mensajes del proveedor ProviderModificarUsuari.
     * Luego llamamos al método llamarRecyclerView para cargar los mensajes en el RecyclerView.
     */
    private fun initRecyclerView() {
        ProviderModificarUsuari.missatgeListModificarUsuari.clear()
        llamarRecyclerView()
    }

    /**
     * Esta función se encarga de llamar al RecyclerView y mostrar los usuarios en él.
     * Primero se limpia la lista de usuarios existente, luego se realiza una consulta a la base de datos Firestore
     * y se obtienen todos los documentos de la colección "Usuarios". Si la consulta no está vacía, se recorren todos los documentos
     * y se crea un objeto de tipo MissatgeModificarUsuari con los datos del documento. Se verifica si la lista de usuarios está vacía,
     * en caso de que sea así, se añade el objeto creado a la lista, de lo contrario, se verifica si el usuario ya existe en la lista,
     * si no existe se añade al RecyclerView. Finalmente, se establece el layout manager y el adapter para mostrar los usuarios en el RecyclerView.
     */
    private fun llamarRecyclerView() {

        lifecycleScope.launch {
            var consulta = bd.collection("Usuaris").get().await()
            if (!consulta.isEmpty) {
                for (document in consulta) {
                    var count=0
                    val wallItem = MissatgeModificarUsuari(
                        nom = document["nomUsuari"].toString(),
                        email = document["gmail"].toString()
                    )
                    if (ProviderModificarUsuari.missatgeListModificarUsuari.isEmpty()) {
                        ProviderModificarUsuari.missatgeListModificarUsuari.add(wallItem)
                    } else {
                        for (i in ProviderModificarUsuari.missatgeListModificarUsuari) {
                            if (wallItem.nom == i.nom) {
                                count++
                            }
                        }
                        if (count == 0) {
                            ProviderModificarUsuari.missatgeListModificarUsuari.add(wallItem)
                        }
                    }
                }
                binding.recyclerViewmodificarUsuari.layoutManager = LinearLayoutManager(context)
                binding.recyclerViewmodificarUsuari.adapter =
                    AdapterModificarUsuari(ProviderModificarUsuari.missatgeListModificarUsuari.toMutableList())
            }
        }
    }
}