package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.FragmentConfiguracioAdministradorBinding
import cat.copernic.comunicatsprodis.databinding.FragmentConfiguracioUsuariBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

/**

 * Clase que representa la configuración de un administrador. En esta clase se pueden realizar acciones como cerrar sesión,
 * crear grupos, gestionar grupos, añadir usuarios, modificar usuarios y ver una localización en un mapa.
 * También se encarga de establecer el layout y los listeners necesarios para cada una de estas acciones.
 */
class Configuracio_administrador : Fragment() {

    private var _binding: FragmentConfiguracioAdministradorBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth

    /**
     * Método encargado de establecer el layout y los listeners necesarios para cada una de las acciones
     * disponibles en la configuración de un administrador.
     * @param inflater El LayoutInflater que se utilizará para inflar la vista.
     * @param container El contenedor que se utilizará para inflar la vista.
     * @param savedInstanceState El estado de la instancia anterior del fragmento.
     * @return La vista generada para el fragmento de configuración del administrador.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentConfiguracioAdministradorBinding.inflate(inflater, container, false)
        auth = Firebase.auth
        binding.configuracioAdministradorBtnTancarSessio.setOnClickListener {
            auth.signOut()
            activity?.finish()
        }
        binding.configuracioAdministradorModificarUsuari.setOnClickListener {
            val action = Configuracio_administradorDirections.actionConfiguracioAdministradorToModificarUsuari()
            findNavController().navigate(action)
        }
        binding.configuracioAdministradorBtnCrearGrups.setOnClickListener {
            findNavController().navigate(R.id.action_configuracio_administrador_to_crearGrups)
        }
        binding.configuracioAdministradorBtnGestioGrups!!.setOnClickListener {
            findNavController().navigate(R.id.action_configuracio_administrador_to_gestio_grup)
        }
        binding.configuracioAdministradorBtnModificarGrups?.setOnClickListener {
            findNavController().navigate(R.id.action_configuracio_administrador_to_gestio_grup)
        }
        binding.configuracioAdministradorAfegirUsuari.setOnClickListener {
            findNavController().navigate(R.id.action_configuracio_administrador_to_crearUsuari)
        }
        binding.localitzacio.setOnClickListener {
            findNavController().navigate(R.id.action_configuracio_administrador_to_maps2)
        }

        return binding.root
    }

}