package cat.copernic.comunicatsprodis

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import cat.copernic.comunicatsprodis.databinding.FragmentEditarUsuarisBinding
import cat.copernic.comunicatsprodis.model.Tutor
import cat.copernic.comunicatsprodis.model.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.checkerframework.checker.units.qual.K

/**
 * Clase que se encarga de mostrar una interfaz para editar un usuario existente en la base de datos,
 * se inicializa la vista mediante un binding, se establecen los listeners para los botones de guardar y cancelar
 * y se establecen los métodos para leer los datos introducidos por el usuario y editar un objeto Usuario
 * existente en la base de datos.
 */
class EditarUsuaris : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var _binding: FragmentEditarUsuarisBinding? = null
    private val binding get() = _binding!!
    private lateinit var tutors1: ArrayList<Tutor>
    private lateinit var auth: FirebaseAuth
    private var bd = FirebaseFirestore.getInstance()

    private val args: EditarUsuarisArgs by navArgs()

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentEditarUsuarisBinding.inflate(inflater, container, false)
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        consultaUsuari()


        binding.registreCancelar.setOnClickListener { view ->
            view.findNavController().navigate(R.id.action_editarUsuaris_to_modificarUsuari)
        }

        binding.registreGuardar.setOnClickListener {
            lifecycleScope.launch {
                var usuaris = llegirDades()
                var count = 0
                val result =
                    bd.collection("Usuaris").get().await()


                if (usuaris.nomUsuari.isNotEmpty()) {
                    afegirUsuari(usuaris)

                    val action =
                        EditarUsuarisDirections.actionEditarUsuarisToModificarUsuari()
                    findNavController().navigate(action)

                } else {
                    //binding.crearCircularTextInputEditTextNomCiuclar.error=getString(R.string.errorjaHiaHaUnaCircularAmbMateixNom)
                }
            }
        }
    }

    /**
     * Lee los datos introducidos por el usuario y crea un objeto de tipo Usuari con estos.
     * @return Un objeto Usuari con los datos introducidos por el usuario.
     */
    fun llegirDades(): Usuari {
        //array tutors
        tutors1 = arrayListOf()
        //Guardem les dades introduïdes per l'usuari
        val gmail = binding.editarUsuariEditemailTutor1.text.toString()
        val nomUsuari = binding.editarUsuariEditnomUsuari.text.toString()
        val direccio = binding.editarUsuariEditDireccio.text.toString()
        val telefon = binding.editarUsuariEditTelefon.text.toString()
        val nomTutor1 = binding.editarUsuariEditnomTutor1.text.toString()
        val gmailtutor1 = binding.editarUsuariEditemailTutor1.text.toString()
        val nomTutor2 = binding.registreEditnomTutor2.text.toString()
        val gmailtutor2 = binding.registreEditemailTutor2.text.toString()
        val admin = binding.checkBoxAdministradorEditarUsuari.isChecked
        //Afegim els Tutors introduïts per l'usuari a l'atribut treballadors
        tutors1.add(Tutor(gmailtutor1, nomTutor1))
        tutors1.add(Tutor(gmailtutor2, nomTutor2))
        return Usuari(gmail, nomUsuari, direccio, telefon, tutors1, admin)
    }


    /**
     * Agrega un objeto de tipo Usuario a la base de datos.
     * @param usuari El objeto Usuario a agregar a la base de datos.
     */
    fun afegirUsuari(usuari: Usuari) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                eliminarUsuari()
            }
        }
        //Afegim una subcolecció igual que afegim una col.lecció però penjant de la col.lecció on està inclosa.
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                actualizarUsuari()
            }
        }


    }

    /**
     * Consulta un usuario específico en la base de datos y lo almacena en un objeto Usuario.
     * Luego, se actualizan los campos de la vista con los datos del usuario consultado.
     */
    fun consultaUsuari() {

        val usuari =
            bd.collection("Usuaris").document(args.safeArgsEditarUsusaris.email).get()
                .addOnSuccessListener { usuari ->
                    var gmailtutor1 = usuari.data?.get("gmail")
                    var nombretutor1 = usuari.data?.get("nomUsuari")

                    var admin = usuari.getBoolean("admin").toString()

                    binding.editarUsuariEditnomUsuari.setText(args.safeArgsEditarUsusaris.nom)
                    binding.editarUsuariEditemailTutor1.setText(args.safeArgsEditarUsusaris.email)
                    binding.registreEditnomTutor2.setText(nombretutor1.toString())
                    binding.registreEditemailTutor2.setText(gmailtutor1.toString())
                    binding.editarUsuariEditDireccio.setText(usuari["direccio"].toString())
                    binding.editarUsuariEditTelefon.setText(usuari["telefon"].toString())
                    if (admin == "true"){
                        binding.checkBoxAdministradorEditarUsuari.setChecked(true)
                    } else if(admin == "false")
                        binding.checkBoxAdministradorEditarUsuari.setChecked(false)
                }
                }




    private suspend fun eliminarUsuari() {
        bd.collection("Usuaris").document(args.safeArgsEditarUsusaris.email).delete()
            .await()
    }
    private suspend fun actualizarUsuari() {

        var usuari = llegirDades()
        val result = bd.collection("Usuaris").document(args.safeArgsEditarUsusaris.email).set(usuari)
        result.await()
    }
}