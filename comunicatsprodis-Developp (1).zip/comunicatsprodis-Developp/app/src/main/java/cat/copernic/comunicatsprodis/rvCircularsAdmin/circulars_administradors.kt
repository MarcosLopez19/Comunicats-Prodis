package cat.copernic.comunicatsprodis.rvCircularsAdmin

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.comunicatsprodis.R
import cat.copernic.comunicatsprodis.databinding.FragmentCircularsAdministradorsBinding
import cat.copernic.comunicatsprodis.rvCircularsAdmin.adapter.CircularsAdapterAdmin
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * Clase fragmento para la gestión de circulares por parte del administrador.
 * Utiliza un RecyclerView para mostrar la lista de circulares existentes y permite añadir nuevas circulares.
 */
class circulars_administradors : Fragment() {
    private var _binding: FragmentCircularsAdministradorsBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()
    private var param1: String? = null
    private var param2: String? = null


    /**
     * Sobreescribe el método onCreate de la clase Activity.
     * Se ejecuta al crear la vista, se utiliza para inicializar variables y establecer la configuración de la vista.
     * @param savedInstanceState, un objeto Bundle que contiene el estado anterior de la actividad si fue destruida.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CircularsAdminProvider.CircularsAdminList
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }

    }


    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de circulares de administrador.
     */
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentCircularsAdministradorsBinding.inflate(inflater)
        return binding.root

    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.actionButtonCrate.setOnClickListener() {
            val action =
                circulars_administradorsDirections.actionCircularsAdministradorsToCrearCircular()
            findNavController().navigate(action)
        }
        configSwipe()
        initRecyclerView()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment circulars_administradors.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            circulars_administradors().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }


    /**
     * Inicializa el RecyclerView con los datos de las circulares existentes en la base de datos.
     */
    private fun initRecyclerView() {
        CircularsAdminProvider.CircularsAdminList.clear()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                rellenarCircularsAdminProvider()
            }
        }


    }

    /**
     * Se encarga de obtener los datos de las circulares existentes en la base de datos y añadirlos a la lista de circulares.
     */
    suspend fun rellenarCircularsAdminProvider() {

        lifecycleScope.launch {
            // Obtiene una QuerySnapshot con todos los documentos de la colección "Circulars" de la base de datos
            val result =  bd.collection("Circulars").get().await()

            // Itera sobre cada documento en el resultado
            for (document in result) {
                var count = 0
                // Crea un nuevo objeto CircularsAdmin con algunos datos del documento
                val wallItem = CircularsAdmin(
                    nombreCircular = document.id,
                    contenido = document["contingut"].toString(),
                    imgPerfil = R.drawable.foto_perfil,
                    imgEdit = R.drawable.lapiz25dp,
                    imgDelete = R.drawable.papelera25dp
                )
                // Si la lista CircularsAdminProvider.CircularsAdminList está vacía, añade el nuevo objeto a la lista
                if (CircularsAdminProvider.CircularsAdminList.isEmpty()) {
                    CircularsAdminProvider.CircularsAdminList.add(wallItem)
                } else {
                    // Si la lista no está vacía, comprueba si hay un elemento con el mismo nombre en la lista
                    for (i in CircularsAdminProvider.CircularsAdminList) {
                        if (wallItem.nombreCircular == i.nombreCircular) {
                            count++
                        }
                    }
                    // Si no hay un elemento con el mismo nombre, añade el nuevo objeto a la lista
                    if (count == 0) {
                        CircularsAdminProvider.CircularsAdminList.add(wallItem)
                    }
                }
            }
            // Establece un LinearLayoutManager para el RecyclerView y un CircularsAdapterAdmin como adaptador
            // del RecyclerView, pasando la lista de CircularsAdmin como parámetro
            binding.recyclerViewCircularAdmin.layoutManager = LinearLayoutManager(context)
            binding.recyclerViewCircularAdmin.adapter =
                CircularsAdapterAdmin(CircularsAdminProvider.CircularsAdminList.toMutableList())
        }
    }


    /**
     * Configura el swipe refresh en la vista de autorizaciones del administrador.
     * Crea un retraso de 1 segundo antes de actualizar la lista, limpia la lista de CircularesAdmin,
     * lanza una corrutina para rellenar la lista en un hilo de background y oculta la barra de progreso de actualización.
     */
    // Configura el listener del gesto de deslizar hacia abajo para actualizar la lista de CircularsAdmin
    fun configSwipe() {
        binding.swipe.setOnRefreshListener {
            // Crea un retraso de 1 segundo antes de actualizar la lista
            Handler(Looper.getMainLooper()).postDelayed({
                // Limpia la lista de CircularsAdmin
                CircularsAdminProvider.CircularsAdminList.clear()
                // Lanza una corrutina para rellenar la lista en un hilo de background
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        rellenarCircularsAdminProvider()
                    }
                }
                // Oculta la barra de progreso de actualización
                binding.swipe.isRefreshing = false
            }, 1000)
        }
    }
}