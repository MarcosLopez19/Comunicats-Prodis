package cat.copernic.comunicatsprodis.rvCircularsUsuaris

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


/**
 * Clase que representa una circular.
 * @property NombreCircular nombre de la Circular
 * @property contenido el contenido de la Circular
 * @property img imagen de un avatar
 * @constructor Crea una nueva instancia de Circulars con los parámetros especificados.
 * @Implements [Parcelable] para permitir la serialización y deserialización de esta clase.
 */
@Parcelize
data class Circulars(
    var nombreCircular: String,
    var contenido: String,
    var img: Int
    ): Parcelable

