package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.comunicatsprodis.databinding.FragmentGestioGrupsBinding
import cat.copernic.comunicatsprodis.rvGestioGrups.AdapterGestioGrup
import cat.copernic.comunicatsprodis.rvGestioGrups.MissatgeGestioGrup
import cat.copernic.comunicatsprodis.rvGestioGrups.ProviderGestioGrup
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Clase para modificar grupos existentes en la base de datos.
 * Utiliza un RecyclerView para mostrar los grupos existentes y permite seleccionar uno para editarlo.
 * Utiliza una conexión con Firebase para obtener y actualizar la información de los grupos.
 */
class ModificarGrups : Fragment() {

    private var _binding: FragmentGestioGrupsBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()

    /**
     * Sobreescribe el método onCreate de la clase Activity.
     * Se ejecuta al crear la vista, se utiliza para inicializar variables y establecer la configuración de la vista.
     * @param savedInstanceState, un objeto Bundle que contiene el estado anterior de la actividad si fue destruida.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ProviderGestioGrup.missatgeListGestioGrup
    }

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autorizaciones de administrador.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentGestioGrupsBinding.inflate(inflater)
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecycleRView()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                llamarRecyclerView()
            }
        }
    }

    /**
     * Inicializa la lista de grupos para mostrar en el RecyclerView.
     */
    private fun initRecycleRView() {
        ProviderGestioGrup.missatgeListGestioGrup.clear()
    }

    /**
     * Función para llenar un RecyclerView con la información de los grupos existentes en la base de datos.
     * Utiliza una conexión con Firebase para obtener los grupos existentes y almacenarlos en una lista.
     * Luego, asigna esa lista al RecyclerView y establece un adapter para mostrar los datos en pantalla.
     */
    suspend fun llamarRecyclerView() {
        lifecycleScope.launch {
            var resultat = bd.collection("Grups").get().await()
            if (!resultat.isEmpty) {
                for (document in resultat) {
                    var count = 0
                    val wallItem = MissatgeGestioGrup(
                        nomGrup = document.id
                    )
                    if (ProviderGestioGrup.missatgeListGestioGrup.isEmpty()) {
                        ProviderGestioGrup.missatgeListGestioGrup.add(wallItem)
                    } else {
                        for (i in ProviderGestioGrup.missatgeListGestioGrup) {
                            if (wallItem.nomGrup == i.nomGrup) {
                                count++
                            }
                        }
                        if (count == 0) {
                            ProviderGestioGrup.missatgeListGestioGrup.add(wallItem)
                        }
                    }
                }
                binding.gestioGrupsRecycleView?.layoutManager = LinearLayoutManager(context)
                binding.gestioGrupsRecycleView?.adapter = AdapterGestioGrup(ProviderGestioGrup.missatgeListGestioGrup.toMutableList())
            }
        }
    }
}