package cat.copernic.comunicatsprodis

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.FragmentCircularsUsuarisBinding
import cat.copernic.comunicatsprodis.databinding.FragmentConfiguracioUsuariBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

/**
 * Clase para la configuración del usuario. Extiende de la clase Fragment.
 * Utiliza FirebaseAuth para la autenticación del usuario y controla los eventos de los botones de cierre de sesión,
 * cambio de foto de perfil y selección de localización.
 */
class Configuracio_Usuari : Fragment() {
    private var _binding: FragmentConfiguracioUsuariBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth

    /**
     * Método que se ejecuta al crear la vista del fragmento. Aquí se inicializa la vista mediante un binding, se establece la autenticación de Firebase y se establecen los listeners para los botones de cierre de sesión, foto de perfil y localización.
     * @param inflater objeto LayoutInflater que se utiliza para inflar la vista
     * @param container contenedor donde se insertará la vista
     * @param savedInstanceState estado anterior de la aplicación
     * @return la vista creada
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentConfiguracioUsuariBinding.inflate(inflater, container, false)
        auth= Firebase.auth
        binding.btnTancaSesio.setOnClickListener {
            auth.signOut()
            activity?.finish()
        }
        binding.btnFotoPerfil.setOnClickListener {
            var action = Configuracio_UsuariDirections.actionConfiguracioUsuariToFotoPerfilUsuari()
            findNavController().navigate(action)
        }
        binding.localitzacio.setOnClickListener {
            findNavController().navigate(R.id.action_configuracio_to_maps)
        }

        return binding.root
    }

}