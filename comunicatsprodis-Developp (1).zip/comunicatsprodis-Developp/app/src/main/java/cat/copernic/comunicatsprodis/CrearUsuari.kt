package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.FragmentCrearUsuariBinding
import cat.copernic.comunicatsprodis.model.Tutor
import cat.copernic.comunicatsprodis.model.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Clase que maneja la creación de Usuarios en el sistema.
 */
class CrearUsuari : Fragment() {
    private lateinit var tutors: ArrayList<Tutor>
    private var _binding: FragmentCrearUsuariBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth
    private var bd = FirebaseFirestore.getInstance()
    private val utils = Utils()

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentCrearUsuariBinding.inflate(inflater)
        auth = Firebase.auth
        tutors = arrayListOf()
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.crearUsuariGuardar.setOnClickListener {
            lifecycleScope.launch {
                withContext(Dispatchers.Unconfined) {
                    var correu = binding.crearUsuariEditemailTutor1.text.toString()
                    var contrasenya = binding.crearUsuariEditContrasenya.text.toString()
                    var contrasenyaBis = binding.crearUsuariEditRepetirContrasenya.text.toString()

                    if (contrasenya.equals(contrasenyaBis) && campEsBuit(
                            correu,
                            contrasenya,
                            contrasenyaBis
                        )
                    ) {
                        var usuaris = llegirDades()

                        if (!utils.isValidEmail(usuaris.gmail)) {
                            binding.crearUsuariEditemailTutor1.error =
                                "email incorrete!!"
                        } else if (!utils.isValidPhoneNumber(usuaris.telefon)) {
                            binding.crearUsuariTelefonTextInput.error =
                                "numero de telefon incorrecte!!"

                        } else if (!utils.isAlpha(usuaris.nomUsuari)) {
                            binding.crearUsuariEditnomUsuari.error =
                                "el nom d'usuari no pot contenir numeros!!"

                        } else if (!utils.isAlpha(usuaris.tutor[0].nomUsuari)) {
                            binding.crearUsuariEditemailTutor1.error =
                                "el nom del tutor no pot contenir numeros!!"

                        } else if (usuaris.gmail.isNotEmpty()) {
                            //Afegim una subcolecció igual que afegim una col.lecció però penjant de la col.lecció on està inclosa.
                            registrar(correu, contrasenya, usuaris)

                        }
                    }
                }
            }
        }
    }

    /**
     * Comprueba si los campos de correo, contraseña y confirmación de contraseña están vacíos.
     * @param correu El campo del correo electrónico.
     * @param contrasenya El campo de la contraseña.
     * @param contrasenyaBis El campo de confirmación de la contraseña.
     * @return true si todos los campos no están vacíos, false si al menos uno de ellos está vacío.
     */
    fun campEsBuit(correu: String, contrasenya: String, contrasenyaBis: String): Boolean {
        return correu.isNotEmpty() && contrasenya.isNotEmpty() && contrasenyaBis.isNotEmpty()
    }

    /**
     * Lee los datos introducidos por el usuario y crea un objeto de tipo Usuario con estos.
     * @return Un objeto Usuario con los datos introducidos por el usuario.
     */
    fun llegirDades(): Usuari {
        //Guardem les dades introduïdes per l'usuari
        var gmail = binding.crearUsuariEditemailTutor1.text.toString()
        var nomUsuari = binding.crearUsuariEditnomUsuari.text.toString()
        var direccio = binding.crearUsuariEditDireccio.text.toString()
        var telefon = binding.crearUsuariEditTelefon.text.toString()
        var nomTutor1 = binding.crearUsuariEditnomTutor1.text.toString()
        var gmailtutor1 = binding.crearUsuariEditemailTutor1.text.toString()
        var nomTutor2 = binding.crearUsuariEditnomTutor2.text.toString()
        var gmailtutor2 = binding.crearUsuariEditemailTutor2.text.toString()
        var admin = binding.checkBoxAdministrador.isChecked
        //Afegim els Tutors introduïts per l'usuari a l'atribut treballadors
        tutors.add(Tutor(gmailtutor1, nomTutor1))
            tutors.add(Tutor(gmailtutor2, nomTutor2))
        return Usuari( gmail, nomUsuari, direccio, telefon, tutors, admin)
    }

    /**
     * Añade un usuario a la base de datos.
     * @param usuaris objeto de tipo Usuari que contiene la informacion del usuario a añadir.
     */
    fun afegirUsuari(usuaris: Usuari) {

        //Afegim una subcolecció igual que afegim una col.lecció però penjant de la col.lecció on està inclosa.
        bd.collection("Usuaris").document(usuaris.gmail).set(usuaris).addOnSuccessListener {
        }
            .addOnFailureListener { //No s'ha afegit el departament...
                /* val builder = AlertDialog.Builder(this)
                 builder.setMessage("NO SE AÑADE NADA")
                 builder.setPositiveButton("Aceptar", null)
                 val dialog = builder.create()
                 dialog.show()*/
            }
    }

    /**
     * Función para registrar un usuario en la aplicación utilizando su correo y contraseña.
     * @param correu El correo electrónico del usuario.
     * @param contrasenya La contraseña del usuario.
     * @param usuaris Los datos del usuario a registrar.
     */
    fun registrar(correu: String, contrasenya: String, usuaris: Usuari) {
        auth.createUserWithEmailAndPassword(correu, contrasenya)
            .addOnCompleteListener {
               if (it.isSuccessful) {
                   afegirUsuari(usuaris)
                   findNavController().navigate(R.id.action_crearUsuari_to_configuracio_administrador)
               }
        }
            .addOnFailureListener {
                val builder = AlertDialog.Builder(requireContext())
                builder.setMessage("El Registre ha fallat")
                builder.setPositiveButton("Aceptar", null)
                val dialog = builder.create()
                dialog.show()
            }
        }
    }

