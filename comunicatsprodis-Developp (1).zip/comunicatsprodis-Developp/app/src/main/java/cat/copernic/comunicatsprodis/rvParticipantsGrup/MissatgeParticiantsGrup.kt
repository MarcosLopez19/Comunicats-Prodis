package cat.copernic.comunicatsprodis.rvParticipantsGrup

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Clase para almacenar los datos de un participante de un grupo.
 * @property nom El nombre del participante.
 * @property email El correo electrónico del participante.
 * @constructor Crea una nueva instancia de MissatgeParticiantsGrup con los parámetros especificados.
 * @Implements [Parcelable] para permitir la serialización y deserialización de esta clase.
 */
@Parcelize
data class MissatgeParticiantsGrup(
    val nom: String,
    val email: String
): Parcelable
