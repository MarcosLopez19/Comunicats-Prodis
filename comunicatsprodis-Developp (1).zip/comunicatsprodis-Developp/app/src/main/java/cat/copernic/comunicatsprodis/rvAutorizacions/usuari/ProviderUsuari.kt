package cat.copernic.comunicatsprodis.rvAutorizacions.usuari

import cat.copernic.comunicatsprodis.rvAutorizacions.admin.provider.Companion.missatgeList


/**
 * Clase que provee una lista de Missatge.
 * @property missatgeListUsuari lista de Missatge
 * @constructor Crea una nueva instancia de la clase ProviderUsuari.
 */
class ProviderUsuari {
    companion object {
        val missatgeListUsuari = ArrayList<Missatge>()
    }
}