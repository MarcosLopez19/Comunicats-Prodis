package cat.copernic.comunicatsprodis.rvModificarUsuari

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MissatgeModificarUsuari (
    val nom : String,
    val email : String
): Parcelable