package cat.copernic.comunicatsprodis.rvResultatsAutorizacio.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.comunicatsprodis.databinding.ItemPersonesautoritzacioBinding
import cat.copernic.comunicatsprodis.rvResultatsAutorizacio.PersonesAutoritzacio

class PersonesAutoritzacioAdapter(private val personesAutoritzacioList: List<PersonesAutoritzacio>) : RecyclerView.Adapter<PersonesAutoritzacioAdapter.PersonesViewHolder>() {



        inner class PersonesViewHolder(val binding: ItemPersonesautoritzacioBinding):RecyclerView.ViewHolder(binding.root)

        private var binding: ItemPersonesautoritzacioBinding? = null
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PersonesViewHolder {

        val binding= ItemPersonesautoritzacioBinding.inflate(LayoutInflater.from(parent.context),parent, false)

            return PersonesViewHolder(binding)
        }

    override fun onBindViewHolder(holder: PersonesViewHolder, position: Int) {
            with(holder) {
                with(personesAutoritzacioList[position]) {
                    binding.nompersona.text = this.nom
                }
            }
        }

        override fun getItemCount(): Int = personesAutoritzacioList.size

   }

