package cat.copernic.comunicatsprodis.rvCircularsAdmin

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Clase que representa una Circular creada por el administrador.
 * @property NombreCircular nombre de la Circular
 * @property contenido el contenido de la Circular
 * @property imgPerfil imagen de un avatar
 * @property imgEdit imagen usada para editar la circular
 * @property imgDelete imagen usada para elimnar la circular
 * @constructor Crea una nueva instancia deCiruclarsAdmin con los parámetros especificados.
 * @Implements [Parcelable] para permitir la serialización y deserialización de esta clase.
 */
@Parcelize
data class CircularsAdmin(
    val nombreCircular: String,
    val contenido: String,
    val imgPerfil: Int,
    val imgEdit: Int,
    val imgDelete: Int
    ): Parcelable

