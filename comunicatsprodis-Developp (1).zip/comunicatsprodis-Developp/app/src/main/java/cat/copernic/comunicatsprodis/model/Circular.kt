package cat.copernic.comunicatsprodis.model

import com.google.firebase.firestore.Exclude


data class Circular(
    @get:Exclude var nomCircular:String,
    var Contingut:String,
    var Destinataris:String)
//, var Destenitaris:String