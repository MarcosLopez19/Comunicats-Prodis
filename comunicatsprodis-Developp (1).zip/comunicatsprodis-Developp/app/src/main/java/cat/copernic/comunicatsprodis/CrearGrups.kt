package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.view.isEmpty
import androidx.core.view.isNotEmpty
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.FragmentCrearGrupsBinding
import cat.copernic.comunicatsprodis.model.Grup
import cat.copernic.comunicatsprodis.model.Tutor
import cat.copernic.comunicatsprodis.model.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * Clase que maneja la creación de Grupos en el sistema.
 */
class CrearGrups : Fragment() {

    private var _binding: FragmentCrearGrupsBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()
    private lateinit var auth: FirebaseAuth

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentCrearGrupsBinding.inflate(inflater, container, false)
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = Firebase.auth
        //array usuari

        binding.crearGrupsCancelar.setOnClickListener {
            findNavController().navigate(R.id.action_crearGrups_to_configuracio_administrador)
        }
        binding.creargrups.setOnClickListener {
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {//llegir dades de la base de dades
                    comprovaGrup()
                }
            }
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment CrearGrups.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            CrearGrups().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    /**
     * Método para leer los datos introducidos por el usuario y guardarlos en una nueva instancia de la clase Grupo.
     * @return una nueva instancia de Grupo con los datos introducidos por el usuario.
     */
    fun llegirDades(): Grup {
        //Guardem les dades introduïdes per l'usuari
        var nomGrup = binding.editNomGrup.text.toString()
        var nomUsuari = binding.editUsuarisGrup.text.toString()
        var gmailTutor = binding.editTutor.text.toString()


        //Afegim els Tutors introduïts per l'usuari a l'atribut treballadors
        //tutors.add(Tutor(gmailTutor, String()))
        //usuaris.add(Usuari(gmailTutor, nomUsuari, String(), String(), tutors))

        return Grup("", nomGrup)
    }


    /**
     * Esta función se encarga de añadir grupos a la base de datos.
     * @param grups es un objeto de tipo Grup que contiene la información del grupo a añadir.
     * La función agrega primero el grupo a la colección "Grups" en la base de datos.
     * Si los campos "editUsuarisGrup" y "editTutor" no están vacíos, agrega un usuario con el gmail del tutor al grupo en cuestión.
     */
    fun afegirGrups(grups: Grup) {
        bd.collection("Grups").document(grups.nomgrup).set(grups)

        if (binding.editUsuarisGrup.text!!.isNotEmpty() && binding.editTutor.text!!.isNotEmpty()) {
            bd.collection("Grups").document(grups.nomgrup).collection("Usuaris")
                .document(binding.editUsuarisGrup.text.toString()).set(
                    hashMapOf(
                        "Gmail tutor1" to binding.editTutor.text.toString()
                    )
                )
        }

    }

    /**
     * Comprueba si un grupo ya existe en la base de datos. Si no existe, se agrega y se redirige al usuario a la pantalla de configuración de administrador.
     * Si el grupo ya existe, se muestra un mensaje de error al usuario.
     */
    suspend fun comprovaGrup() {
        lifecycleScope.launch {
            var grup = llegirDades()
            var count = 0
            val result = bd.collection("Grups").get().await()

            if (!result.isEmpty)
                for (document in result)
                    if (grup.nomgrup == document.id)
                        count++

            if (grup.nomgrup.isNotEmpty() && count == 0) {
                if (comprovaUsuari() || binding.editTutor.text!!.isEmpty()) {
                    afegirGrups(grup)
                    val action = CrearGrupsDirections.actionCrearGrupsToConfiguracioAdministrador()
                    findNavController().navigate(action)
                    Utils.notification(grup.nomgrup, "Grup", requireContext())
                } else {
                    binding.editTutor.error = getString(R.string.noExisteUsuari)
                }
            } else {
                binding.nomGrupTextInput.error = getString(R.string.GrupRepetit)
            }

        }
    }

    /**
     * Mediante esta función comprobamos que exista algun Usuario con el gmail que inscribe el usuario
     */
    suspend fun comprovaUsuari(): Boolean {
        var existe = false
        val query = bd.collection("Usuaris").get().await()

        for (document in query)
            if (document.id == binding.editTutor.text.toString())
                existe = true

        return existe
    }
}


