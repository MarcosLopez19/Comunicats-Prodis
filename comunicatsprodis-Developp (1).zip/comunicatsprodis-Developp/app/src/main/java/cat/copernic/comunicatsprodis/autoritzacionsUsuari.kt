package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.comunicatsprodis.databinding.AutoritzacioUsuariItemBinding
import cat.copernic.comunicatsprodis.rvAutorizacions.usuari.AdapterAutoritzacionsUsuari2
import cat.copernic.comunicatsprodis.rvAutorizacions.usuari.ProviderUsuari
import cat.copernic.comunicatsprodis.databinding.FragmentAutoritzacionsUsuariBinding
import cat.copernic.comunicatsprodis.rvAutorizacions.usuari.Missatge
import cat.copernic.comunicatsprodis.rvCircularsUsuaris.CircularsProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Clase fragmento para la gestión de autorizaciones por parte del Usuario.
 * Utiliza un RecyclerView para mostrar la lista de autorizaciones existentes.
 */
class autoritzacionsUsuari : Fragment() {
    /**
     * Instancia de la base de datos de Firebase
     */
    val bd = FirebaseFirestore.getInstance()

    /**
     * Variable para la vinculación del layout del fragmento
     */
    private var _binding: FragmentAutoritzacionsUsuariBinding? = null

    /**
     * Acceso rápido a la vinculación del layout del fragmento
     */
    private val binding get() = _binding!!

    /**
     * Sobreescribe el método onCreate de la clase Activity.
     * Se ejecuta al crear la vista, se utiliza para inicializar variables y establecer la configuración de la vista.
     * @param savedInstanceState, un objeto Bundle que contiene el estado anterior de la actividad si fue destruida.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ProviderUsuari.missatgeListUsuari
    }

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentAutoritzacionsUsuariBinding.inflate(inflater)
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initRecylceView()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                llamarRecyclerView()
            }
        }
    }

    /**
     * Método para inicializar el RecyclerView de autorizaciones de usuario.
     * Limpia la lista de autorizaciones de usuario para evitar duplicados.
     */
    private fun initRecylceView() {
        ProviderUsuari.missatgeListUsuari.clear()
    }

    /**
     * Método suspendido que llama al RecyclerView de autorizaciones de usuario.
     * Realiza una consulta a la base de datos en la colección "Autorizaciones" y obtiene todos los documentos.
     * Itera sobre cada documento y crea un nuevo objeto Missatge con algunos datos del documento.
     * Realiza otra consulta a la base de datos, en la subcolección "Usuarios" del documento en la colección "Grupos" con el ID del documento "Autorizaciones"
     * Recorre cada documento en la subcolección "Usuarios" y obtiene el valor del campo "Gmail tutor1" del documento.
     * Si el valor es igual al correo del usuario actual, añade el objeto Missatge a la lista de autorizaciones de usuario.
     * Establece un LinearLayoutManager para el RecyclerView y un AdapterAutorizacionesUsuario como adaptador del RecyclerView, pasando la lista de autorizaciones de usuario como parámetro.
     */
    suspend fun llamarRecyclerView() {
        lifecycleScope.launch {
            var resultat = bd.collection("Autoritzacions").get().await()
            if (!resultat.isEmpty) {
                for (document in resultat) {
                        var count=0
                        val wallItem = Missatge(
                            nomMissatge = document.id,
                            descripcio = document["contingut"].toString()
                        )
                    // Realiza otra consulta a la base de datos, en la subcolección "Usuaris" del documento en la colección "Grups" con el ID del documento "Circulars"
                    var countEstaUsuari = 0
                    val query = bd.collection("Grups")
                        .document(document["destinataris"].toString())
                        .collection("Usuaris")
                        .get()
                        .await()
                    // Recorre cada documento en la subcolección "Usuaris"
                    for (document2 in query) {
                        // Obtiene el valor del campo "Gmail tutor1" del documento
                        val query3 = document2["Gmail tutor1"].toString()
                        // Si el valor es igual al correo del usuario actual
                        if (query3 == Utils.getCorreoUserActural()) {
                            // Incrementa el contador
                            countEstaUsuari++
                        }
                    }
                    if (ProviderUsuari.missatgeListUsuari.isEmpty() && countEstaUsuari != 0) {
                        ProviderUsuari.missatgeListUsuari.add(wallItem)
                    } else if (countEstaUsuari != 0){
                        for (i in ProviderUsuari.missatgeListUsuari) {
                            if (wallItem.nomMissatge == i.nomMissatge) {
                                count ++
                            }
                        }
                        if (count == 0) {
                            ProviderUsuari.missatgeListUsuari.add(wallItem)
                        }
                    }
                    }
                binding.autoritzacionsUsuariRecycleView.layoutManager = LinearLayoutManager(context)
                binding.autoritzacionsUsuariRecycleView.adapter =
                    AdapterAutoritzacionsUsuari2(ProviderUsuari.missatgeListUsuari.toList())

            }
        }
    }
}