package cat.copernic.comunicatsprodis

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer

/**
 * Clase que representa la pantalla de inicio de la aplicación.
 * Muestra una pantalla durante 3 segundos antes de iniciar la pantalla de inicio de sesión.
 */

class SplashScreen : AppCompatActivity() {

    /**
     * Método que se ejecuta al crear la actividad.
     * Oculta la ActionBar y inicia un temporizador antes de iniciar la pantalla de inicio de sesión.
     * @param savedInstanceState estado guardado de la instancia anterior. Puede ser nulo.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //esconde la ActionBar
        setContentView(R.layout.activity_splash_screen)
        if(supportActionBar != null)
            supportActionBar!!.hide()
        startTimer()
    }

    /**
     * Método que inicia un temporizador de 3 segundos antes de iniciar la pantalla de inicio de sesión.
     * El temporizador cuenta hacia atrás desde 3 segundos, y cada vez que finaliza un segundo, se ejecuta el método onFinish()
     */
    fun startTimer(){
        object: CountDownTimer(3000, 1000){
            override fun onTick(millisUntilFinished: Long) {
            }

            override fun onFinish() {
                val intent = Intent(applicationContext, Login::class.java).apply{}
                startActivity(intent)
                finish()
            }

        }.start()
    }
}