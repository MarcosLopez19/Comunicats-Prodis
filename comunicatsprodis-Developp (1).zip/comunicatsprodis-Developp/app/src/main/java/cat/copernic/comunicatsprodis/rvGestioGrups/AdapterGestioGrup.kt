package cat.copernic.comunicatsprodis.rvGestioGrups

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.comunicatsprodis.ModificarGrupsDirections
import cat.copernic.comunicatsprodis.autoritzacionsAdminDirections
import cat.copernic.comunicatsprodis.databinding.AutoritzacioAdminItemBinding
import cat.copernic.comunicatsprodis.databinding.ItemGestioGrupBinding
import cat.copernic.comunicatsprodis.model.Autoritzacio
import cat.copernic.comunicatsprodis.model.Grup
import cat.copernic.comunicatsprodis.rvAutorizacions.admin.MissatgeAdmin
import cat.copernic.comunicatsprodis.rvGestioGrups.ProviderGestioGrup.Companion.missatgeListGestioGrup
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
* Clase AdapterGestioGrup es un adaptador para la lista de mensajes de gestión de grupos.
* @param missatge Lista de objetos MissatgeGestioGrup que se mostrarán en la vista.
* @constructor Crea una nueva instancia de AdapterGestioGrup con los parámetros especificados.
* @property binding Vinculación para el diseño del elemento de la gestión de grupos.
* @Implements [RecyclerView.Adapter] para proporcionar un adaptador personalizado para la vista de RecyclerView.
 */
class AdapterGestioGrup(private val missatge: MutableList<MissatgeGestioGrup>) : RecyclerView.Adapter<AdapterGestioGrup.ViewHolderGestioGrup>() {

    /**
    * Clase interna que representa un ViewHolder para el diseño del elemento de la gestión de grupos.
    * @param binding La vinculación para el diseño del elemento de la gestión de grupos.
    */
    inner class ViewHolderGestioGrup(val binding: ItemGestioGrupBinding): RecyclerView.ViewHolder(binding.root)

    private var bd = FirebaseFirestore.getInstance()
    private var binding: ItemGestioGrupBinding? = null

    /**
    * Método que se ejecuta al crear un nuevo ViewHolder para el diseño del elemento de la gestión de grupos
    * @param parent El ViewGroup padre del nuevo ViewHolder.
    * @param viewType El tipo de vista del nuevo ViewHolder.
    * @return Un nuevo ViewHolder para el diseño del elemento de la gestión de grupos.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderGestioGrup {
        val binding = ItemGestioGrupBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ViewHolderGestioGrup(binding)
    }

    /**
    * Método que se ejecuta al enlazar un ViewHolder existente con un elemento de la lista de gestión de grupos en una posición específica.
    * @param holder El ViewHolder existente que se va a enlazar.
    * @param position La posición del elemento en la lista de gestión de grupos.
     */
    override fun onBindViewHolder(holder: ViewHolderGestioGrup, position: Int) {
        with(holder) {
            with(missatgeListGestioGrup[position]) {
                binding.itemTvNomGestioGrup.text = this.nomGrup
            }

            var grup = llegirDades(binding)
            binding.imgbuttonEditGestioGrup.setOnClickListener { view ->
                navegacionAdapterToEdit(view, missatgeListGestioGrup[position])
            }
            binding.imgButtonPapeleraGestioGrup.setOnClickListener { view ->

                GlobalScope.launch {
                    var documents = bd.collection("Grups").get().await()
                    for (document in documents) {
                        if (binding.itemTvNomGestioGrup.text.toString() == document.id) {
                            eliminarGrup(grup)
                            bd.collection("Grups").document(document.id).delete().await()
                        }
                    }
                }
                missatge.removeAt(position)
                notifyItemRemoved(position)
            }
            binding.imgButtonAddpart.setOnClickListener { view ->
                navegacionAdapterToEliminar(view, missatgeListGestioGrup[position])
            }
        }
    }
    /**
     * Función encargada de obtener la cantidad de elementos en la lista de mensajes.
     * @return un entero que representa la cantidad de elementos en la lista de mensajes.
     */
    override fun getItemCount(): Int = missatge.size

    /**
    * Función privada encargada de navegar desde la pantalla de gestión de grupos hacia la pantalla de participantes del grupo específico.
    * @param view la vista actual desde la cual se realiza la navegación
    * @param datosAdmin objeto de tipo MissatgeGestioGrup que contiene los datos del grupo seleccionado
     */
    private fun navegacionAdapterToEdit(view: View, datosAdmin: MissatgeGestioGrup) {
        val action = ModificarGrupsDirections.actionGestioGrupToParticipantsGrup(datosAdmin.nomGrup)
        view.findNavController().navigate(action)
    }

    /**
    * Función privada encargada de navegar desde la pantalla de gestión de grupos hacia la pantalla de eliminación de un grupo específico.
    * @param view la vista actual desde la cual se realiza la navegación
    * @param datosAdmin objeto de tipo MissatgeGestioGrup que contiene los datos del grupo seleccionado
     */
    private fun navegacionAdapterToEliminar(view: View, datosAdmin: MissatgeGestioGrup) {
        val action = ModificarGrupsDirections.actionGestioGrupToModificarGrup(datosAdmin)
        view.findNavController().navigate(action)
    }

    fun llegirDades(binding: ItemGestioGrupBinding): String {
        //Guardem les dades introduïdes per l'usuari
        return binding.itemTvNomGestioGrup.text.toString()
    }

    private fun eliminarGrup(nom: String) {

        bd.collection("Grups").document(nom).collection("Usuaris").get().addOnSuccessListener { documents ->
            for (document in documents) {
                bd.collection("Grups").document(nom).collection("Usuaris").document(document.id).delete()
            }
        }
    }
}