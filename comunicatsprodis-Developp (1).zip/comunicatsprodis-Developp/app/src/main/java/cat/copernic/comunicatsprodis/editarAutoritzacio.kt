package cat.copernic.comunicatsprodis

import android.os.Bundle
import android.provider.SyncStateContract.Helpers.update
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import cat.copernic.comunicatsprodis.databinding.FragmentEditarAutoritzacioBinding
import cat.copernic.comunicatsprodis.databinding.FragmentEnviarCircularBinding
import cat.copernic.comunicatsprodis.model.*
import cat.copernic.comunicatsprodis.rvAutorizacions.admin.MissatgeAdmin
import cat.copernic.comunicatsprodis.rvAutorizacions.usuari.Missatge
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Clase que se encarga de mostrar una interfaz para editar una autorización existente en la base de datos,
 * se inicializa la vista mediante un binding, se establecen los listeners para los botones de aceptar y cancelar y
 * se establecen los métodos para leer los datos introducidos por el usuario y editar un objeto Autorización existente
 * en la base de datos.
 */
class editarAutoritzacio : Fragment() {

    private var _binding: FragmentEditarAutoritzacioBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()


    private val args: editarAutoritzacioArgs by navArgs()

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        _binding = FragmentEditarAutoritzacioBinding.inflate(inflater)
        return binding.root
    }
    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.editarAutoritzacioNomAutoritzacio.isEnabled = false

        binding.editarAutoritzacioNomAutoritzacio.setText(args.autoritzacioAdminArgument.nomMissatge)
        binding.editarAutoritzacioText.setText(args.autoritzacioAdminArgument.missatge)
        binding.editarAutoritzacioDescripcio.setText(args.autoritzacioAdminArgument.descripcio)
        binding.editarAutoritzacioDestinataris.setText(args.autoritzacioAdminArgument.destinataris)

        binding.editarAutoritzacioAceptar.setOnClickListener {

            lifecycleScope.launch {
                withContext(Dispatchers.IO) {//llegir dades de la base de dades
                    comprovaAutoritzacio()
                }
            }
        }
        binding.editarAutoritzacioCancelar.setOnClickListener {
            val action = editarAutoritzacioDirections.actionEditarAutoritzacioToAutoritzacionsAdmin()
            findNavController().navigate(action)
        }
    }

    /**
     * Lee los datos introducidos por el usuario y crea un objeto de tipo Autorización con estos.
     * @return Un objeto Autorización con los datos introducidos por el usuario.
     */
    fun llegirDades(): Autoritzacio{
        var nomAutoritzacio = binding.editarAutoritzacioNomAutoritzacio.text.toString()
        var contingut = binding.editarAutoritzacioText.text.toString()
        var descripcio = binding.editarAutoritzacioDescripcio.text.toString()
        var destinataris = binding.editarAutoritzacioDestinataris.text.toString()

        return Autoritzacio(nomAutoritzacio, descripcio, contingut, /*grups, */null, destinataris)
    }


    /**
     * Edita un objeto Autorización existente en la base de datos.
     * @param autoritzacio El objeto Autorización a editar.
    */
    fun EditarAutoritzacio(autoritzacio: Autoritzacio) {

        //Si el usuario cambia el grupo de destinataris o de descripción lo actualizamos en la base de datos
        if (binding.editarAutoritzacioDestinataris.text.toString() != args.autoritzacioAdminArgument.destinataris) {
            bd.collection("Autoritzacions").document(autoritzacio.nom).update("destinataris", autoritzacio.Destinataris)
        }
        if (binding.editarAutoritzacioDescripcio.text.toString() != args.autoritzacioAdminArgument.descripcio) {
            bd.collection("Autoritzacions").document(autoritzacio.nom).update("descripcio", autoritzacio.descripcio)
        }
    }

    /**
     * Comprueba si una autorización ya existe en la base de datos y si es así, la edita.
     * También comprueba que el campo de destinatarios no esté vacío.
     */
    suspend fun comprovaAutoritzacio() {

        lifecycleScope.launch {
            var autoritzacio = llegirDades()
            var count = 0
            val result = bd.collection("Autoritzacions").get().await()

            if (!result.isEmpty)
                for (document in result)
                    if (autoritzacio.nom == document.id && autoritzacio.nom != args.autoritzacioAdminArgument.nomMissatge)
                        count++

            if (autoritzacio.nom.isNotEmpty() && count == 0) {
                if (comprovaDestinatari(llegirDades())) {
                    EditarAutoritzacio(autoritzacio)
                    val action = editarAutoritzacioDirections.actionEditarAutoritzacioToAutoritzacionsAdmin()
                    findNavController().navigate(action)
                    Utils.notification(llegirDades().nom, "Autoritzacio", requireContext())
                } else {
                    binding.editarAutoritzacioDestinataris.error = getString(R.string.Destinatari)
                }
            } else {
                binding.editarAutoritzacioNomAutoritzacio.error = getString(R.string.AutoritzacioRepetida)
            }
        }
    }

    /**
     * Mediante esta función comprobamos que exista algun grupo con el nombre que inscribe el usuario
     */
    suspend fun comprovaDestinatari(autoritzacio: Autoritzacio): Boolean {
        var existe = false
        val query = bd.collection("Grups").get().await()

        for (document in query)
            if (document["Nom"].toString() == autoritzacio.Destinataris)
                existe = true

        return existe
    }
}

private fun DocumentReference.update(id: Int, nom: String) {

}
