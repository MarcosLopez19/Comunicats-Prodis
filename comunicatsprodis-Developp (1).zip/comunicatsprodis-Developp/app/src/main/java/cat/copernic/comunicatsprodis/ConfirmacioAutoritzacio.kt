package cat.copernic.comunicatsprodis

import android.app.Application
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import cat.copernic.comunicatsprodis.databinding.FragmentConfirmacioAutoritzacioBinding
import cat.copernic.comunicatsprodis.databinding.FragmentFmenuBinding
import cat.copernic.comunicatsprodis.model.Autoritzacio
import cat.copernic.comunicatsprodis.model.Usuari
import cat.copernic.comunicatsprodis.rvAutorizacions.usuari.Missatge
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import io.grpc.okhttp.internal.Util
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


/**
 * Clase que se encarga de mostrar la pantalla de confirmación de autorización.
 * Recoge los argumentos pasados desde la pantalla anterior y muestra el nombre y la descripción del mensaje.
 * Contiene dos botones, uno para cancelar y otro para enviar la confirmación.
 * Al pulsar en el botón de enviar, se actualiza en la base de datos el estado de la autorización del usuario actual.
 */
class ConfirmacioAutoritzacio : Fragment() {

    private val args: ConfirmacioAutoritzacioArgs by navArgs()

    private var _binding: FragmentConfirmacioAutoritzacioBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()
    //private lateinit var auth: FirebaseAuth
    //val currentUser = auth.currentUser
    private lateinit var auth: FirebaseAuth

    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    /**
     * Sobreescribe el método onCreate de la clase Activity.
     * Se ejecuta al crear la vista, se utiliza para inicializar variables y establecer la configuración de la vista.
     * @param savedInstanceState, un objeto Bundle que contiene el estado anterior de la actividad si fue destruida.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        _binding = FragmentConfirmacioAutoritzacioBinding.inflate(inflater, container, false)
        auth = Firebase.auth
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.confirmacioAutoritzacioNom.text = args.mensaje.nomMissatge

        binding.confirmacioAutoritzacioDescripcioAutoritzacio.text = args.mensaje.descripcio

        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                comprovaSignat()
            }
        }

        binding.confirmacioAutoritzacioButtonCancelar.setOnClickListener {
            var action = ConfirmacioAutoritzacioDirections.actionConfirmacioAutoritzacioToAutoritzacionsUsuari()
            findNavController().navigate(action)
        }

        binding.confirmacioAutoritzacioButtonEnviar.setOnClickListener {

            signat()
            var action = ConfirmacioAutoritzacioDirections.actionConfirmacioAutoritzacioToAutoritzacionsUsuari()
            findNavController().navigate(action)
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment ConfirmacioAutoritzacio.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            ConfirmacioAutoritzacio().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    /**
     * Esta función se utiliza para actualizar el estado de autorización de un usuario en la base de datos.
     * Se accede a la colección "Autorizaciones" y al documento específico y se actualiza el campo "signat"
     * con el valor del estado del botón de radioButton. También se establece un nuevo documento en la colección "Usuarios"
     * con el correo electrónico del usuario actual y el estado de autorización actual.
     */
    fun signat() {

        auth = Firebase.auth
                val user = auth.currentUser
        bd.collection("Autoritzacions").document(args.mensaje.nomMissatge).collection("Usuaris").document(user!!.email.toString()).update("signat", binding.confirmacioAutoritzacioRadioButtonSi.isChecked)
        lifecycleScope.launch {


                bd.collection("Autoritzacions").document(args.mensaje.nomMissatge).collection("Usuaris")//Col.lecció
             .document(Utils.getCorreoUserActural()).set(
                 hashMapOf(
                     "gmail" to Utils.getCorreoUserActural(),
                     "signat" to binding.confirmacioAutoritzacioRadioButtonSi.isChecked
                 )
             )

        }
    }
    suspend fun comprovaSignat() {
        lifecycleScope.launch {
            var existe = false

            val query = bd.collection("Autoritzacions").document(args.mensaje.nomMissatge).collection("Usuaris").document(Utils.getCorreoUserActural()).get().await()

            var hola = query["signat"].toString()

            if (hola == "true"){
                binding.confirmacioAutoritzacioRadioButtonSi.setChecked(true)
            } else if(hola == "false")
                binding.confirmacioAutoritzacioRadioButtonNo.setChecked(true)
        }
    }
}