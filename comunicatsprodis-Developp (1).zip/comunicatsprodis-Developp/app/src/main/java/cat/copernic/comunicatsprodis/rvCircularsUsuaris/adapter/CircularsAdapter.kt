package cat.copernic.comunicatsprodis.rvCircularsUsuaris.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.comunicatsprodis.R
import cat.copernic.comunicatsprodis.autoritzacionsUsuariDirections
import cat.copernic.comunicatsprodis.rvCircularsUsuaris.circulars_usuarisDirections

import cat.copernic.comunicatsprodis.databinding.CircularsRecycleviewUsuariBinding
import cat.copernic.comunicatsprodis.rvAutorizacions.usuari.Missatge
import cat.copernic.comunicatsprodis.rvCircularsUsuaris.Circulars
import org.checkerframework.checker.units.qual.C


class CircularsAdapter(private val circularList:List<Circulars>): RecyclerView.Adapter<CircularsAdapter.CircularsViewHolder>(){

    inner class CircularsViewHolder(val binding: CircularsRecycleviewUsuariBinding):RecyclerView.ViewHolder(binding.root)

    private var binding: CircularsRecycleviewUsuariBinding? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CircularsViewHolder {

        val binding= CircularsRecycleviewUsuariBinding.inflate(LayoutInflater.from(parent.context),parent, false)

        return CircularsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CircularsViewHolder, position: Int) {
        with(holder) {
            with(circularList[position]) {
                binding.textViewnombre.text = this.nombreCircular
                binding.textViewContenido.text = this.contenido
                binding.photoPerfilRecycleView.setImageResource(this.img)
            }
            binding.CardRvCircular.setOnClickListener { view ->
                navegacionCircularsUsuari(view, circularList.get(position))
            }


        }
    }
    private fun navegacionCircularsUsuari(view : View, datos: Circulars) {

        val action = circulars_usuarisDirections.actionCircularsUsuarisToVisualizarCiruclar(datos)

        view.findNavController().navigate(action)
    }

    override fun getItemCount(): Int = circularList.size

}