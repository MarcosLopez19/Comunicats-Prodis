package cat.copernic.comunicatsprodis.model

import com.google.firebase.firestore.Exclude


data class Autoritzacio(
    @get:Exclude var nom:String,
    var descripcio:String,
    var contingut:String,
    var usuaris:ArrayList<Usuari>?,
    /*var grups:ArrayList<Grup>, */
    var Destinataris: String?)
