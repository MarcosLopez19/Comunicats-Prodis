package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import cat.copernic.comunicatsprodis.databinding.FragmentModificarGrupBinding
import cat.copernic.comunicatsprodis.model.Autoritzacio
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Clase EliminarGrup que extiende de Fragment.
 * En esta clase se modifica un grupo de la base de datos de Firebase.
*/
class EliminarGrup : Fragment() {

    private var _binding: FragmentModificarGrupBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()

    private val args: EliminarGrupArgs by navArgs()

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autorizaciones de administrador.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        _binding = FragmentModificarGrupBinding.inflate(inflater)
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.editNomGrup.isEnabled = false
        binding.editNomGrup.setText(args.aaaaaaaaa.nomGrup)

        binding.eliminargrups.setOnClickListener {
            editarGrup()
        }
        binding.eliminarGrupsCancelar.setOnClickListener {
            val action = EliminarGrupDirections.actionModificarGrupToGestioGrup()
            findNavController().navigate(action)
        }

    }
    /**
     * Esta función se encarga de editar un grupo existente en la base de datos de Firebase.
     * Primero, se comprueba si el usuario existe en la base de datos.
     * Si existe, se añade al grupo especificado en los argumentos del fragmento y se muestra un diálogo de confirmación.
     * Si no existe, se muestra un error en el campo de usuario.
     */
     fun editarGrup() {
         lifecycleScope.launch {
             if (comprovaDestinatari()) {
                 bd.collection("Grups").document(args.aaaaaaaaa.nomGrup).collection("Usuaris")
                     .document(binding.editNomUsuarisGrup?.text.toString()).set(
                         hashMapOf(
                             "Gmail tutor1" to binding.editTutorMG?.text.toString()
                         )
                     ).addOnSuccessListener {
                         val builder = AlertDialog.Builder(requireContext())
                         builder.setMessage(getString(R.string.UsuariAfegit))
                         builder.setPositiveButton(R.string.aceptar, null)
                         val dialog = builder.create()
                         dialog.show()
                     }
                 val action = EliminarGrupDirections.actionModificarGrupToGestioGrup()
                 findNavController().navigate(action)
             } else {
                 binding.editTutorMG?.error = getString(R.string.noExisteUsuari)
             }
         }
    }

    /**
     * Comprueba si existe un destinatario en la base de datos de Firestore.
     * @return true si existe el destinatario, false en caso contrario
     */
    suspend fun comprovaDestinatari(): Boolean {
        var existe = false
        val query = bd.collection("Usuaris").get().await()

        for (document in query)
            if (document.id == binding.editTutorMG?.text.toString())
                existe = true

        return existe
    }
}
