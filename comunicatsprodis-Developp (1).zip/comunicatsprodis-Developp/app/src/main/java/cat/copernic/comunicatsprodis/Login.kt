package cat.copernic.comunicatsprodis

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import cat.copernic.comunicatsprodis.databinding.LoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class Login : AppCompatActivity() {

    private lateinit var binding: LoginBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var correu: String
    private var bd = FirebaseFirestore.getInstance()
    private val utils = Utils()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()

        //esconde la ActionBar
        if (supportActionBar != null)
            supportActionBar!!.hide()

        binding = LoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //val builder = AlertDialog.Builder(this)
        auth = Firebase.auth


        //Implementem els listeners per quan l'usuari cliqui un dels botons

        binding.buttonLoginAccedir.setOnClickListener {

            //Guardem les dades introduïdes per l'usuari en el formulari mitjançant text i les transformem amb un String (toString())
            correu = binding.textInputEditTextLoginGmail.text.toString().replace(" ", "")
            var contrasenya =
                binding.textInputEditTextLoginPassword.text.toString().replace(" ", "")

            //Comprovem que els camps no estan buit
            if (correu.isNotEmpty() && contrasenya.isNotEmpty()) {
                //Loguinem a l'usuari mitjançant la funció loguinar creada per nosaltres
                loguinar(correu, contrasenya)
            } else if (correu.isEmpty()) {
                binding.textInputEditTextLoginGmail.error = getString(R.string.correoVacio)
            } else {
                binding.textInputEditTextLoginPassword.error =
                    getString(R.string.contrasenyaVacia)
            }
        }
        //boton pagina de registrarse
        binding.buttonLoginRegister.setOnClickListener {
            //Anem a l'activity del registre
            startActivity(Intent(this, Register::class.java))
            overridePendingTransition(R.anim.translate_left_side,R.anim.translate_left_side)
            finish()
        }
        binding.recuperarContrasenya.setOnClickListener {
            //Anem a l'activity del registre
            startActivity(Intent(this, RecuperarContrasenya::class.java))
            overridePendingTransition(R.anim.translate_left_side,R.anim.translate_left_side)
            finish()
        }
    }

    fun correo(correu1: String): String {
        return correu1
    }

    override fun onStart() {
        val intentAdmin = Intent(this, menuAdmin::class.java)
        val intent = Intent(this, Menu::class.java)
        super.onStart() //Cridem al la funció onStart() perquè ens mostri per pantalla l'activity
        //currentUser és un atribut de la classe FirebaseAuth que guarda l'usuari autenticat. Si aquest no està autenticat, el seu valor serà null.
        val currentUser = auth.currentUser
        auth = Firebase.auth
        if (currentUser != null) {
            lifecycleScope.launch {
                val queryAdmin =
                    bd.collection("Usuaris").document(utils.getCorreoUserActural()).get().await()

                if (queryAdmin.getBoolean("admin")== true) {
                    startActivity(intentAdmin)
                    //generamos una animacion que hemos generado en la carpeta res/anim llamada zoom_in
                    overridePendingTransition(R.anim.zoom_in, R.anim.zoom_in)
                } else {
                    startActivity(intent)
                    //generamos una animacion que hemos generado en la carpeta res/anim llamada zoom_in
                    overridePendingTransition(R.anim.zoom_in, R.anim.zoom_in)
                }
            }

        }
    }

    //Funció per loguinar a un usuari mitjançant Firebase Authentication
    fun loguinar(correu: String, contrasenya: String) {
        //Loguinem a l'usuari
        val intentAdmin = Intent(this, menuAdmin::class.java)
        val intent = Intent(this, Menu::class.java)
        auth.signInWithEmailAndPassword(correu, contrasenya)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) { //El loguin (task) s'ha completat amb exit...
                    //Anem al mainActivity des d'aquesta pantalla
                    lifecycleScope.launch {

                        val queryAdmin =
                            bd.collection("Usuaris").document(utils.getCorreoUserActural()).get().await()

                        if (queryAdmin.getBoolean("admin")== true) {
                            startActivity(intentAdmin)
                            //generamos una animacion que hemos generado en la carpeta res/anim llamada zoom_in
                            overridePendingTransition(R.anim.zoom_in, R.anim.zoom_in)
                        } else {
                            startActivity(intent)
                            //generamos una animacion que hemos generado en la carpeta res/anim llamada zoom_in
                            overridePendingTransition(R.anim.zoom_in, R.anim.zoom_in)
                        }
                    }
                    //finish() //Alliberem memòria un cop finalitzada aquesta tasca.
                } else { //El loguin (task) ha fallat...
                    //Mostrem un missatge a l'usuari mitjançant un Toast
                    val builder = AlertDialog.Builder(this)
                    builder.setMessage(getString(R.string.LoginFallat))
                    builder.setPositiveButton(R.string.aceptar, null)
                    val dialog = builder.create()
                    dialog.show()
                }
            }
    }

    private fun createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "name"
            val descriptionText = "descripcion"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("1", name, importance).apply {
                description = descriptionText
            }
            // Register the channel with the system
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    }
