package cat.copernic.comunicatsprodis.model


data class Usuari(val gmail:String, var nomUsuari:String, var direccio:String, var telefon:String, var tutor:ArrayList<Tutor>, var admin:Boolean?=false, var signat:Boolean? = false)