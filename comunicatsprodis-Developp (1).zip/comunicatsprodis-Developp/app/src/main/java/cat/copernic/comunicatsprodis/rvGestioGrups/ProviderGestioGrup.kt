package cat.copernic.comunicatsprodis.rvGestioGrups

class ProviderGestioGrup {
    companion object {
        val missatgeListGestioGrup = ArrayList<MissatgeGestioGrup>()
    }
}