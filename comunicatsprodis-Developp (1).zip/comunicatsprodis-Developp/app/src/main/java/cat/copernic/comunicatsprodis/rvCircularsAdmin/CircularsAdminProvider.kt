package cat.copernic.comunicatsprodis.rvCircularsAdmin



/**
 * Clase que provee una lista de CircualresAdmin.
 * @property CircularsAdminList lista de CicularesAdmin
 * @constructor Crea una nueva instancia de la clase Provider.
 */
class CircularsAdminProvider {
    companion object {
        //generamos los objetes y los rellenamos con la clase Circulars
        val CircularsAdminList = mutableListOf<CircularsAdmin>(
            )

    }
}