package cat.copernic.comunicatsprodis.rvAutorizacions.admin


/**
* Clase que provee una lista de MissatgeAdmin.
* @property missatgeList lista de MissatgeAdmin
* @constructor Crea una nueva instancia de la clase Provider.
 */

class provider {
    companion object {
        val missatgeList = mutableListOf<MissatgeAdmin>(
        )
    }
}