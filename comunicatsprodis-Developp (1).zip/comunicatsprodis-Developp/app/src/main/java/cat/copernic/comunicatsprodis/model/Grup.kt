package cat.copernic.comunicatsprodis.model

import com.google.firebase.firestore.Exclude


data class Grup(
    @get:Exclude val id:String,
    var nomgrup:String)
