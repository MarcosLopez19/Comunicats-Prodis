package cat.copernic.comunicatsprodis

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat.startActivity
import cat.copernic.comunicatsprodis.databinding.LoginBinding
import cat.copernic.comunicatsprodis.databinding.RecuperarContrasenyaBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

/**
 * Clase encargada de la recuperación de contraseñas.
 * Esta clase permite enviar un correo electrónico para restablecer la contraseña del usuario.
 * Crea una interfaz que permite ingresar el correo y mediante un botón enviar el correo de recuperación.
 * También tiene un botón para cancelar y volver al Login.
 */
class RecuperarContrasenya : AppCompatActivity() {

    private lateinit var binding: RecuperarContrasenyaBinding

    private lateinit var auth: FirebaseAuth

    /**
     * Método que se ejecuta al crear la actividad. En este se infla la vista, se inicializa la variable de
     * autenticación de Firebase y se implementan los listeners para los botones.Se recoge el correo introducido y
     * se llama al método para resetear la contraseña. Si se pulsa el botón de cancelar, se regresa al login.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = RecuperarContrasenyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //Inicialitzem la variable de tipus FirebaseAuth amb una instància d'aquesta classe
        auth = Firebase.auth
        //Implementem els listeners per quan l'usuari cliqui un dels botons
        binding.buttonRecuperarContrasenya.setOnClickListener {
            val correu = binding.textInputEditTextEmail.text.toString() //Guardem el correu introduït per l'usuari

            if (correu.isNotEmpty()) {
                resetContrasenya(correu)
            }
        }
        binding.buttonCancelarRecuperarcontrasenya.setOnClickListener {
            //Anem al mainActivity des d'aquesta pantalla
            startActivity(Intent(this, Login::class.java))
            finish() //Alliberem memòria un cop finalitzada aquesta tasca.
        }
    }

    /**
     * Método encargado de enviar el correo de recuperación de contraseña
     * @param email dirección de correo electrónico ingresada por el usuario
     */
    private fun resetContrasenya (email: String) {
        auth.setLanguageCode("ca")
        auth.sendPasswordResetEmail(email).addOnCompleteListener() { task ->
            if (task.isSuccessful)
            {
                //Anem al mainActivity des d'aquesta pantalla
                startActivity(Intent(this, Login::class.java))
                finish() //Alliberem memòria un cop finalitzada aquesta tasca.
            }
            else
            {
                val builder = AlertDialog.Builder(this)
                builder.setMessage("No s'ha pogut enviar el correu")
                builder.setPositiveButton("Aceptar", null)
                val dialog = builder.create()
                dialog.show()
            }
        }
    }
}

