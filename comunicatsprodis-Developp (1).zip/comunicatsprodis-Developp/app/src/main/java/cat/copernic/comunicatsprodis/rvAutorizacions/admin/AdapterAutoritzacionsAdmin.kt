package cat.copernic.comunicatsprodis.rvAutorizacions.admin

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.comunicatsprodis.autoritzacionsAdminDirections
import cat.copernic.comunicatsprodis.databinding.AutoritzacioAdminItemBinding
import cat.copernic.comunicatsprodis.rvAutorizacions.admin.provider.Companion.missatgeList
import cat.copernic.comunicatsprodis.model.Autoritzacio
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
* Clase AdapterAutoritzacionsAdmin es un adaptador para la lista de mensajes de administrador.
* @param missatge Lista de objetos MissatgeAdmin que se mostrarán en la vista.
* @constructor Crea una nueva instancia de AdapterAutoritzacionsAdmin con los parámetros especificados.
* @Implements [RecyclerView.Adapter] para proporcionar un adaptador personalizado para la vista de RecyclerView.
*/
class AdapterAutoritzacionsAdmin (private var missatge: MutableList<MissatgeAdmin>) :
    RecyclerView.Adapter<AdapterAutoritzacionsAdmin.ViewHolderAdmin>() {
    /**
    * Variable que almacena una instancia de FirebaseFirestore.
     */
    private var bd = FirebaseFirestore.getInstance()

    /**
     * Variable que almacena una instancia de FirebaseFirestore.
     */
    var context: Context? = null

    /**
    * Clase interna que representa un ViewHolder para el diseño del elemento de administrador.
    * @param binding La vinculación para el diseño del elemento de administrador.
     * @
     */
    inner class ViewHolderAdmin(val binding: AutoritzacioAdminItemBinding):
        RecyclerView.ViewHolder(binding.root)

    /**
    * Crea y devuelve un nuevo ViewHolder para el diseño del elemento de administrador.
    * @param parent El ViewGroup padre del nuevo ViewHolder.
    * @param viewType El tipo de vista del nuevo ViewHolder.
    * @return Un nuevo ViewHolder para el diseño del elemento de administrador.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderAdmin {
        val binding = AutoritzacioAdminItemBinding.inflate(
            LayoutInflater.from(parent.context)
            ,parent,
            false)

        return ViewHolderAdmin(binding)
    }

    /**
    * Enlaza un ViewHolder existente con un elemento de la lista de administrador en una posición específica.
    * @param holder El ViewHolder existente que se va a enlazar.
    * @param position La posición del elemento en la lista de administrador.
     */
    override fun onBindViewHolder(holder: ViewHolderAdmin, position: Int) {
        with(holder) {
            with(missatge[position]) {
                binding.itemTvNommissatgeAdmin.text = this.nomMissatge
                binding.itemTvMissatgeAdmin.text = this.missatge
            }
            var autoritzacions = llegirDades(binding)
         /*   holder.binding.itemTvMissatgeAdmin.setOnClickListener { view ->
                iniciarSesion(view)
            }*/
            binding.imgbuttonEdit.setOnClickListener { view ->
                navegacionAutoritzacionsAdminToEdit(view, missatge.get(position))
            }
            binding.imgButtonPapelera.setOnClickListener {

                GlobalScope.launch {
                    withContext(Dispatchers.Main) {
                        val result = withContext(Dispatchers.IO) {bd.collection("Autoritzacions").get().await() }

                        for (document in result) {
                            if (binding.itemTvNommissatgeAdmin.text == document.id) {
                                afegirAutoritzacio(autoritzacions)
                                bd.collection("Autoritzacions")
                                    .document(document.id).delete().await()
                            }

                        }
                    }
                }
                missatge.removeAt(position)
                notifyItemRemoved(position)
            }
        }
    }

    /**
    * Navega a la pantalla de resultatsAutoritzacions.
    * @param view La vista desde la cual se inicia la sesión.
     */
    private fun iniciarSesion(view : View) {

        val action = autoritzacionsAdminDirections.actionAutoritzacionsAdminToResultatsAutoritzacions()
        view.findNavController().navigate(action)
    }

    /**
    * Función encargada de navegar desde la pantalla de autorizaciones de administrador hacia la pantalla de edición de autorizaciones.
    * @param view la vista actual desde la cual se realiza la navegación
    * @param datosAdmin El objeto de tipo MissatgeAdmin
     */
    private fun navegacionAutoritzacionsAdminToEdit(view: View, datosAdmin: MissatgeAdmin) {
        val action = autoritzacionsAdminDirections.actionAutoritzacionsAdminToEditarAutoritzacio(datosAdmin)
        view.findNavController().navigate(action)
    }


    /**
    * Función encargada de añadir una nueva autorización a la base de datos.
    * @param autoritzacio la autorización a ser añadida a la base de datos.
    * Es necesario especificar el nombre de la autorización.
     */
    fun afegirAutoritzacio(autoritzacio: Autoritzacio) {

        bd.collection("Autoritzacions").document(autoritzacio.nom).collection("Usuaris").get().addOnSuccessListener { documents ->
            for (document in documents) {
                bd.collection("Autoritzacions").document(autoritzacio.nom).collection("Usuaris").document(document.id).delete()
            }
        }
    }

    /**
    * Función encargada de leer y guardar los datos introducidos por el usuario en un objeto Autorización.
    * @param binding la vista actual que contiene los campos de texto donde se introducen los datos.
    * @return un objeto Autorización con los datos introducidos por el usuario.
     */

    fun llegirDades(binding: AutoritzacioAdminItemBinding): Autoritzacio {
        //Guardem les dades introduïdes per l'usuari
        var nom = binding.itemTvNommissatgeAdmin.text.toString()
        var contingut = binding.itemTvMissatgeAdmin.text.toString()


        return Autoritzacio(nom, "", contingut, /*grups, */null, "")
    }

    /**
    * Función encargada de obtener la cantidad de elementos en la lista de mensajes.
    * @return un entero que representa la cantidad de elementos en la lista de mensajes.
     */
    override fun getItemCount(): Int = missatge.size

}