package cat.copernic.comunicatsprodis.rvModificarUsuari

class ProviderModificarUsuari {
    companion object {
        val missatgeListModificarUsuari = ArrayList<MissatgeModificarUsuari>()
    }
}