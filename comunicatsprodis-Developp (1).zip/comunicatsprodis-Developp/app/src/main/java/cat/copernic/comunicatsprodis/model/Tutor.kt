package cat.copernic.comunicatsprodis.model

import com.google.firebase.firestore.Exclude

data class Tutor(val gmail:String,var nomUsuari:String)
