package cat.copernic.comunicatsprodis

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.ActivityMenuAdminBinding
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Esta clase representa el menú principal del administrador.
 * Contiene un menú con opciones de configuración y un botón para volver a la página principal.
 * Utiliza una vista de navegación para desplazarse entre las diferentes secciones de la aplicación
 */
class menuAdmin : AppCompatActivity() {
    private lateinit var binding: ActivityMenuAdminBinding
    private var bd = FirebaseFirestore.getInstance()
    private val utils = Utils()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.navHostFragmentContentMainAdmin.getFragment<Fragment>().findNavController().setGraph(R.navigation.nav_graph_administrador)
    }

    /**
     * Crea el menú con opciones de configuración y un botón para volver a la página principal.
     */
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    /**
     * Maneja las acciones del usuario al seleccionar una opción del menú
     */
    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.configuracio -> {
            binding.navHostFragmentContentMainAdmin.findNavController()
                .navigate(R.id.action_fragment1_to_fragment2)
            true
        }
        R.id.flecha -> {
            binding.navHostFragmentContentMainAdmin.findNavController()
                .navigate(R.id.casa)
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }
}

