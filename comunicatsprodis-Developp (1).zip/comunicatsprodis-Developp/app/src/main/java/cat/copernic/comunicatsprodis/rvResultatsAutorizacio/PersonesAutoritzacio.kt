package cat.copernic.comunicatsprodis.rvResultatsAutorizacio

data class PersonesAutoritzacio(
    val nom:String
    )
