package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import cat.copernic.comunicatsprodis.databinding.FragmentEnviarCircularBinding
import cat.copernic.comunicatsprodis.model.Circular
import cat.copernic.comunicatsprodis.rvCircularsAdmin.CircularsAdminProvider
import cat.copernic.comunicatsprodis.enviar_circularArgs
import cat.copernic.comunicatsprodis.enviar_circularDirections
import cat.copernic.comunicatsprodis.rvCircularsAdmin.CircularsAdmin
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


class enviar_circular : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var _binding: FragmentEnviarCircularBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()

    private val args: enviar_circularArgs by navArgs()

    /**
     * Crea y devuelve la vista del fragmento de enviar circulars.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de enviar_circular.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        _binding = FragmentEnviarCircularBinding.inflate(inflater)
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.enviarCircularTextInputEditTextNomCiuclar.setText(args.circularsAdminArgument.nombreCircular)
        binding.text.setText(args.circularsAdminArgument.contenido)

        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                destinatari()
            }
        }

        binding.enviarCiruclarButtonEnviar.setOnClickListener {
            lifecycleScope.launch {

                var circulars = llegirDades()
                var count = 0
                val result =
                    bd.collection("Circulars").get().await()

                if (!result.isEmpty) {
                    for (document in result) {
                        if (circulars.nomCircular == document.id && circulars.nomCircular!=args.circularsAdminArgument.nombreCircular) {
                            count++
                        }
                    }
                }
                if (circulars.nomCircular.isNotEmpty()) {
                    if (count == 0) {
                        if (comprovaDestinatari()) {
                            lifecycleScope.launch {
                                withContext(Dispatchers.IO) {
                                    eliminarCircualar()
                                }
                            }
                            lifecycleScope.launch {
                                withContext(Dispatchers.IO) {
                                    actualizarCircular()
                                }
                            }
                            val action =
                                enviar_circularDirections.actionEnviarCircularToCircularsAdministradors2()
                            findNavController().navigate(action)
                        } else {
                            binding.enviarCircularTextInputEditTextDestinataris.error =
                                getString(R.string.Destinatari)
                        }
                    } else{
                        binding.enviarCircularTextInputEditTextNomCiuclar.error =
                            "Se esta repetin el nom!!"
                    }
                } else {
                    binding.enviarCircularTextInputEditTextNomCiuclar.error =
                        "!!No pot estar el camp buit"
                    //getString("")
                }
            }

        }
        binding.enviarCiruclarButtonCancelar.setOnClickListener() {
            val action =
                enviar_circularDirections.actionEnviarCircularToCircularsAdministradors2()
            findNavController().navigate(action)
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment enviar_circular.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            enviar_circular().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    /**
     * La función 'llegirDades()' se encarga de recoger los datos introducidos por el usuario en los campos correspondientes del layout.
     * Estos datos son el nombre de la circular, el contenido de la misma y los destinatarios.
     * Estos datos son guardados en un objeto de tipo Circular.
     * @return objeto de tipo Circular que contiene los datos introducidos por el usuario.
     */
    fun llegirDades(): Circular {
        //Guardem les dades introduïdes per l'usuari
        val nomCircular = binding.enviarCircularTextInputEditTextNomCiuclar.text.toString()
        val contringut = binding.text.text.toString()
        val destinataris = binding.enviarCircularTextInputEditTextDestinataris.text.toString()
        return Circular(nomCircular, contringut, destinataris)
    }

    /**
     * Esta función se encarga de eliminar una circular
     */
    private suspend fun eliminarCircualar() {
        lifecycleScope.launch(Dispatchers.Main) {
            bd.collection("Circulars").document(args.circularsAdminArgument.nombreCircular).delete()
                .await()
        }
    }

    /**
     * Esta función se encarga de actualizar la información de una circular existente en la base de datos.
     * Toma los datos introducidos por el usuario en la interfaz gráfica y los guarda en la base de datos.
     * Utiliza el nombre de la circular introducida como identificador para actualizar la información en la base de datos.
     */
    private suspend fun actualizarCircular() {
        lifecycleScope.launch(Dispatchers.Main) {
            var circulars = llegirDades()
            val result = bd.collection("Circulars").document(circulars.nomCircular).set(circulars)
            result.await()
        }
    }

    /**
     * Esta función se encarga de recuperar los destinatarios de una circular específica de la base de datos.
     * Recupera el documento con el nombre de la circular pasada como argumento. Una vez obtenido el documento, se recupera el
     * valor del atributo "destinataris" y se establece en el campo de texto correspondiente en la vista.
     */
    suspend fun destinatari() {
        val a =
            bd.collection("Circulars").document(args.circularsAdminArgument.nombreCircular).get()
                .await()
        val nombre = a["destinataris"].toString()
        binding.enviarCircularTextInputEditTextDestinataris.setText(nombre)
    }

    /**
     * Esta función se encarga de comprobar si el destinatario de una circular existe en la base de datos de grupos.
     * @return devuelve true si el destinatario existe en la base de datos de grupos y false en caso contrario.
     */
    suspend fun comprovaDestinatari(): Boolean {
        var existe = false
        val query =
            bd.collection("Grups").get()
                .await()
        for (document in query) {
            val destinatari =
                bd.collection("Circulars").document(args.circularsAdminArgument.nombreCircular)
                    .get()
                    .await()
            val nombre = destinatari["destinataris"].toString()
            if (document["Nom"].toString() == nombre) {
                existe = true
            }
        }
        return existe
    }

    suspend fun compravaRepetida() {
        //comprobar si existe alguna circular con el mismo nombre

    }
}