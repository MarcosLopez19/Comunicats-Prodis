package cat.copernic.comunicatsprodis


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast

import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import cat.copernic.comunicatsprodis.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import cat.copernic.comunicatsprodis.model.Tutor
import cat.copernic.comunicatsprodis.model.Usuari
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Clase que representa la Activity de Regitro. Se encarga de registrar los usuarios
 */
class Register : AppCompatActivity() {

    private lateinit var tutors: ArrayList<Tutor>
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var auth: FirebaseAuth
    private var bd = FirebaseFirestore.getInstance()
    private val utils = Utils()

    /**
     * Se llama después de que la actividad ha sido creada.
     * Inicializa los componentes de la vista y establece los listeners para los botones.
     * @param savedInstanceState El estado previamente guardado de la actividad.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //esconde la ActionBar
        if (supportActionBar != null)
            supportActionBar!!.hide()

        auth = Firebase.auth
        //array tutors
        tutors = arrayListOf()


        binding.registreGuardar.setOnClickListener {
            lifecycleScope.launch {
                withContext(Dispatchers.Unconfined) {//llegir dades de la base de dades

                    var correu = binding.registreEditemailTutor1.text.toString()
                    var contrasenya = binding.registreEditContrasenya.text.toString()
                    var contrasenyaBis = binding.registreEditRepetirContrasenya.text.toString()

                    if (contrasenya.equals(contrasenyaBis) && campEsBuit(
                            correu,
                            contrasenya,
                            contrasenyaBis
                        )
                    ) {

                        var usuaris = llegirDades()


                        //Si hem introduit un codi (és l'identifiacdor del departament, per tant ha de ser obligatori).


                        if (!utils.isValidEmail(usuaris.gmail)) {
                            binding.registreEditemailTutor1.error =
                                "email incorrete!!"
                        } else if (!utils.isValidPhoneNumber(usuaris.telefon)) {
                            binding.registreTelefonTextInput.error =
                                "numero de telefon incorrecte!!"

                        } else if (!utils.isAlpha(usuaris.nomUsuari)) {
                            binding.registreEditnomUsuari.error =
                                "el nom d'usuari no pot contenir numeros!!"

                        } else if (!utils.isAlpha(usuaris.tutor[0].nomUsuari)) {
                            binding.registreEditnomTutor1.error =
                                "el nom del tutor no pot contenir numeros!!"

                        } else if (usuaris.gmail.isNotEmpty()) {
                            //Afegim una subcolecció igual que afegim una col.lecció però penjant de la col.lecció on està inclosa.
                            registrar(correu, contrasenya, usuaris)

                        }

                    }
                }
            }
        }
        binding.registreCancelar.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
            finish()
        }
    }

    /**
     * Comprueba si los campos de correo, contraseña y confirmación de contraseña están vacíos.
     * @param correu El campo del correo electrónico.
     * @param contrasenya El campo de la contraseña.
     * @param contrasenyaBis El campo de confirmación de la contraseña.
     * @return true si todos los campos no están vacíos, false si al menos uno de ellos está vacío.
     */
    fun campEsBuit(correu: String, contrasenya: String, contrasenyaBis: String): Boolean {
        return correu.isNotEmpty() && contrasenya.isNotEmpty() && contrasenyaBis.isNotEmpty()
    }

    //Funció que llegeix les dades introduïdes per un usuari i retorna el departament instanciat amb aquestes
    //dades.
    /**
     * Lee los datos introducidos por el usuario y crea un objeto de tipo Usuario con estos.
     * @return Un objeto Usuario con los datos introducidos por el usuario.
     */
    fun llegirDades(): Usuari {
        //Guardem les dades introduïdes per l'usuari
        var gmail = binding.registreEditemailTutor1.text.toString()
        var nomUsuari = binding.registreEditnomUsuari.text.toString()
        var direccio = binding.registreEditDireccio.text.toString()
        var telefon = binding.registreEditTelefon.text.toString()
        var nomTutor1 = binding.registreEditnomTutor1.text.toString()
        var gmailtutor1 = binding.registreEditemailTutor1.text.toString()
        var nomTutor2 = binding.registreEditnomTutor2.text.toString()
        var gmailtutor2 = binding.registreEditemailTutor2.text.toString()

        //Afegim els Tutors introduïts per l'usuari a l'atribut treballadors
        tutors.add(Tutor(gmailtutor1, nomTutor1))
        tutors.add(Tutor(gmailtutor2, nomTutor2))
        return Usuari(gmail, nomUsuari, direccio, telefon, tutors)
    }

    /**
     * Añade un usuario a la base de datos.
     * @param usuaris objeto de tipo Usuari que contiene la informacion del usuario a añadir.
     */
    fun afegirUsuari(usuaris: Usuari) {

        //Afegim una subcolecció igual que afegim una col.lecció però penjant de la col.lecció on està inclosa.
        bd.collection("Usuaris").document(usuaris.gmail).set(usuaris).addOnSuccessListener {
        }
            .addOnFailureListener { //No s'ha afegit el departament...
                /* val builder = AlertDialog.Builder(this)
                 builder.setMessage("NO SE AÑADE NADA")
                 builder.setPositiveButton("Aceptar", null)
                 val dialog = builder.create()
                 dialog.show()*/
            }
    }

    /**
     * Función para registrar un usuario en la aplicación utilizando su correo y contraseña.
     * @param correu El correo electrónico del usuario.
     * @param contrasenya La contraseña del usuario.
     * @param usuaris Los datos del usuario a registrar.
     */
    fun registrar(correu: String, contrasenya: String, usuaris: Usuari) {
        auth.createUserWithEmailAndPassword(correu, contrasenya)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    //afegir les dades del usuaris al Firestore
                    afegirUsuari(usuaris)
                    startActivity(Intent(this, Menu::class.java))
                    finish()
                } else {
                    val builder = AlertDialog.Builder(this)
                    builder.setMessage("El Registre ha fallat")
                    builder.setPositiveButton("Aceptar", null)
                    val dialog = builder.create()
                    dialog.show()
                }
            }
    }

}