package cat.copernic.comunicatsprodis

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.ActivityMenuBinding
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Clase encargada de mostrar el menú principal de la aplicación.
 * Infla el archivo de recursos de menú R.menu.menu_main y lo agrega al menú de opciones.
 * Se utiliza para navegar entre las diferentes secciones de la aplicación.
 */
class Menu : AppCompatActivity() {
    private var bd = FirebaseFirestore.getInstance()
    private val utils = Utils()
    private lateinit var binding: ActivityMenuBinding

    /**
     * Método que se ejecuta al crear la actividad.
     * Establece el contenido de la vista a binding.root y carga el gráfico de navegación para usuarios.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.navHostFragmentContentMain.getFragment<Fragment>().findNavController()
            .setGraph(R.navigation.nav_graph_usuaris)
    }

    /**
     * Método que se ejecuta cuando se crea el menú de opciones de la actividad.
     * Infla el archivo de recursos de menú R.menu.menu_main y lo agrega al menú de opciones.
     * El objeto menuInflater se utiliza para inflar los archivos de recursos de menú en objetos de menú.
     */
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    /**
     * Este método se ejecuta cuando se selecciona una opción del menú de opciones.
     * Utiliza una expresión when para determinar qué opción se seleccionó.
     * Si se selecciona la opción "configuración", se navega desde el fragmento actual hasta el fragmento de configuración.
     * Si se selecciona la opción "flecha", se navega desde el fragmento actual hasta la pantalla principal.
     * Si se selecciona cualquier otra opción, se invoca al método del padre para manejar la acción.
     */
    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.configuracio -> {
            binding.navHostFragmentContentMain.findNavController()
                .navigate(R.id.action_fragment1_to_fragment2usuari)
            true
        }
        R.id.flecha -> {
            binding.navHostFragmentContentMain.findNavController()
                .navigate(R.id.casa2)

            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }
}
