package cat.copernic.comunicatsprodis.rvAutorizacions.usuari

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Clase que representa un mensaje.
 * @property nomMissatge nombre del mensaje
 * @property descripcio una descripción adicional del mensaje
 * @constructor Crea una nueva instancia de Missatge con los parámetros especificados.
 * @Implements [Parcelable] para permitir la serialización y deserialización de esta clase.
 */
@Parcelize
data class Missatge(
    var nomMissatge : String,
    var descripcio : String
): Parcelable
