package cat.copernic.comunicatsprodis.rvModificarUsuari

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.NavController
import androidx.navigation.findNavController

import androidx.recyclerview.widget.RecyclerView
import cat.copernic.comunicatsprodis.R
import cat.copernic.comunicatsprodis.databinding.ItemModificarUsuariBinding
import cat.copernic.comunicatsprodis.modificarUsuariDirections
import cat.copernic.comunicatsprodis.rvCircularsAdmin.CircularsAdmin
import cat.copernic.comunicatsprodis.rvCircularsAdmin.circulars_administradorsDirections
import cat.copernic.comunicatsprodis.rvModificarUsuari.ProviderModificarUsuari.Companion.missatgeListModificarUsuari
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class AdapterModificarUsuari (private val missatgeModificarUsuari: MutableList<MissatgeModificarUsuari>) : RecyclerView.Adapter<AdapterModificarUsuari.ViewHolderAdmin>() {

    private var bd = FirebaseFirestore.getInstance()
    var context: Context? = null
    inner class ViewHolderAdmin(val binding: ItemModificarUsuariBinding): RecyclerView.ViewHolder(binding.root)

    private var binding: ItemModificarUsuariBinding? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderAdmin {
        val binding = ItemModificarUsuariBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ViewHolderAdmin(binding)
    }

    override fun onBindViewHolder(holder: ViewHolderAdmin, position: Int) {
        with(holder) {
            with(missatgeListModificarUsuari[position]) {
                binding.tvNomUsuari.text = this.nom
                binding.tvEmail.text = this.email
            }
            binding.imgButtonPapelera.setOnClickListener {
                GlobalScope.launch(Dispatchers.Main) {
                    val result =
                        withContext(Dispatchers.IO) { bd.collection("Usuaris").get().await() }

                    for (document in result) {
                        if (binding.tvEmail.text == document["gmail"].toString()) {
                            bd.collection("Usuaris")
                                .document(document["gmail"].toString()).delete()
                                .await()
                            missatgeModificarUsuari.removeAt(position)
                            notifyItemRemoved(position)
                        }
                    }
                }

            }
            binding.imgbuttonEdit.setOnClickListener { view ->
                navegacionCircularsAdmintoEdit(view,missatgeModificarUsuari.get(position))
            }
        }
    }
    private fun navegacionCircularsAdmintoEdit(view: View, datos: MissatgeModificarUsuari) {

        val action =
            modificarUsuariDirections.actionModificarUsuariToEditarUsuaris(datos)
        view.findNavController().navigate(action)
    }
    override fun getItemCount(): Int = missatgeModificarUsuari.size
}