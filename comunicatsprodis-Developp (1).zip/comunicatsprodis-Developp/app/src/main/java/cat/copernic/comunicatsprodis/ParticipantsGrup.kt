package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.comunicatsprodis.databinding.FragmentParticipantsGrupBinding
import cat.copernic.comunicatsprodis.rvParticipantsGrup.AdapteerParticipantsGrup
import cat.copernic.comunicatsprodis.rvParticipantsGrup.MissatgeParticiantsGrup
import cat.copernic.comunicatsprodis.rvParticipantsGrup.ProviderParticipantsGrup
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Clase que representa el fragmento de participantes de un grupo. Se encarga de mostrar los participantes
 * de un grupo específico en una lista y proporciona una funcionalidad para eliminar a un participante de un grupo.
 */
class ParticipantsGrup : Fragment() {
    private var _binding: FragmentParticipantsGrupBinding? = null
    private val binding get() = _binding!!
    val bd = FirebaseFirestore.getInstance()

    private val argsss: ParticipantsGrupArgs by navArgs()

    /**
     * Se llama al crear la instancia del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ProviderParticipantsGrup.missatgeListParticipantsGrup
    }
    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autorizaciones de administrador.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentParticipantsGrupBinding.inflate(inflater)
        return binding.root
    }
    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initRecyclerView()
    }

    /**
     * Inicializa el RecyclerView, limpia la lista de participantes y llama a la función "llamarRecyclerView"
     */
    private fun initRecyclerView() {
        ProviderParticipantsGrup.missatgeListParticipantsGrup.clear()
        llamarRecyclerView()
    }

    /**
     * Esta función se encarga de llamar al RecyclerView de los participantes de un grupo.
     * Realiza una consulta en la base de datos para obtener los participantes del grupo especificado
     * en el argumento "argsss.ooooooo" y los añade al RecyclerView mediante un adaptador.
     */
    private fun llamarRecyclerView() {

        lifecycleScope.launch {
            var consulta = bd.collection("Grups").document(argsss.ooooooo)
                .collection("Usuaris").get().await()
            if (!consulta.isEmpty) {
                for (document in consulta) {
                    var count=0
                    val wallItem = MissatgeParticiantsGrup(
                        nom = document.id.toString(),
                        email = document["Gmail tutor1"].toString()
                    )
                    if (ProviderParticipantsGrup.missatgeListParticipantsGrup.isEmpty()) {
                        ProviderParticipantsGrup.missatgeListParticipantsGrup.add(wallItem)
                    } else {
                        for (i in ProviderParticipantsGrup.missatgeListParticipantsGrup) {
                            if (wallItem.nom == i.nom) {
                                count++
                            }
                        }
                        if (count == 0) {
                            ProviderParticipantsGrup.missatgeListParticipantsGrup.add(wallItem)
                        }
                    }
                }
                binding.participantsGrupRecycleView.layoutManager = LinearLayoutManager(context)
                binding.participantsGrupRecycleView.adapter =
                   AdapteerParticipantsGrup(ProviderParticipantsGrup.missatgeListParticipantsGrup.toMutableList(), argsss.ooooooo)
            }
        }
    }

}