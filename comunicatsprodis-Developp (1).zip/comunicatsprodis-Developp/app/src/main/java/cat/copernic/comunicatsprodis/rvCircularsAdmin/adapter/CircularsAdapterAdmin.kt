package cat.copernic.comunicatsprodis.rvCircularsAdmin.adapter


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.MenuItemCompat.setContentDescription
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.comunicatsprodis.rvCircularsAdmin.circulars_administradorsDirections
import cat.copernic.comunicatsprodis.databinding.CircularsRecycleviewAdministradorBinding
import cat.copernic.comunicatsprodis.rvCircularsAdmin.CircularsAdmin
import cat.copernic.comunicatsprodis.rvCircularsAdmin.CircularsAdminProvider
import cat.copernic.comunicatsprodis.rvCircularsAdmin.circulars_administradors
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await

/**
 * Clase CircularsAdapterAdmin es un adaptador para la circularAdminList de administrador.
 * @param circularAdminList Lista de objetos CircularsAdmin que se mostrarán en la vista.
 * @constructor Crea una nueva instancia de CircularsAdapterAdmin con los parámetros especificados.
 * @Implements [RecyclerView.Adapter] para proporcionar un adaptador personalizado para la vista de RecyclerView.
 */
class CircularsAdapterAdmin(private var circularAdminList: MutableList<CircularsAdmin>) :
    RecyclerView.Adapter<CircularsAdapterAdmin.CircularsAdminViewHolder>() {
    /**
     * Variable que almacena una instancia de FirebaseFirestore.
     */
    private var bd = FirebaseFirestore.getInstance()

    /**
     * Variable que almacena una instancia de FirebaseFirestore.
     */
    var context: Context? = null

    /**
     * Clase interna que representa un ViewHolder para el diseño del elemento de administrador.
     * @param binding La vinculación para el diseño del elemento de administrador.
     * @
     */
    inner class CircularsAdminViewHolder(val binding: CircularsRecycleviewAdministradorBinding) :
        RecyclerView.ViewHolder(binding.root)

    /**
     * Crea y devuelve un nuevo ViewHolder para el diseño del elemento de administrador.
     * @param parent El ViewGroup padre del nuevo ViewHolder.
     * @param viewType El tipo de vista del nuevo ViewHolder.
     * @return Un nuevo ViewHolder para el diseño del elemento de administrador.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CircularsAdminViewHolder {
        val binding = CircularsRecycleviewAdministradorBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CircularsAdminViewHolder(binding)
    }

    /**
     * Enlaza un ViewHolder existente con un elemento de la lista de administrador en una posición específica.
     * @param holder El ViewHolder existente que se va a enlazar.
     * @param position La posición del elemento en la lista de administrador.
     */
    override fun onBindViewHolder(holder: CircularsAdminViewHolder, position: Int) {

        with(holder) {
            with(circularAdminList[position]) {
                binding.textViewnombre.text = this.nombreCircular
                binding.textViewContenido.text = this.contenido
                binding.photoPerfilRecycleView.setImageResource(this.imgPerfil)
                binding.imgbuttonEdit.setImageResource(this.imgEdit)
                binding.imgButtonPapelera.setImageResource(this.imgDelete)
            }
            binding.imgbuttonEdit.setOnClickListener { view ->
                navegacionCircularsAdmintoEdit(view, circularAdminList.get(position))
            }
            binding.imgButtonPapelera.setOnClickListener {
                //corrutina ilo para ejecutrar en el hilo principal
                GlobalScope.launch(Dispatchers.Main) {
                    val result =
                        withContext(Dispatchers.IO) { bd.collection("Circulars").get().await() }

                    for (document in result) {
                        if (binding.textViewnombre.text == document.id) {
                            bd.collection("Circulars")
                                .document(document.id).delete()
                                .await()
                            circularAdminList.removeAt(position)
                            notifyItemRemoved(position)
                        }
                    }
                }
            }
        }
    }

    /**
     * Función encargada de navegar desde la pantalla de circulares de administrador hacia la pantalla de edición de circulares.
     * @param view la vista actual desde la cual se realiza la navegación
     * @param datos El objeto de tipo CircularsAdmin
     */

    private fun navegacionCircularsAdmintoEdit(view: View, datos: CircularsAdmin) {

        val action =
            circulars_administradorsDirections.actionCircularsAdministradors2ToEnviarCircular(datos)
        view.findNavController().navigate(action)
    }


    override fun getItemCount(): Int = circularAdminList.size

}