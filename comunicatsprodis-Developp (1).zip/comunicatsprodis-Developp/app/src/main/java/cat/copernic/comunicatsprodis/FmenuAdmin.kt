package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.FragmentFmenuAdminBinding
import hotchemi.android.rate.AppRate

/**
 * Clase que representa el menú principal del administrador
 * Contiene los botones para acceder a las funciones de circular y autorización
 * y también contiene un botón para acceder a la configuración del administrador
 */
class FmenuAdmin : Fragment() {
    private var _binding: FragmentFmenuAdminBinding? = null
    private val binding get() = _binding!!

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        _binding = FragmentFmenuAdminBinding.inflate(inflater, container, false)

        binding.btnImgCiruclars.setOnClickListener() {
            findNavController().navigate(R.id.action_fmenuAdmin2_to_circulars_administradors)
        }

        binding.btnImgAutorizacions.setOnClickListener() {
            findNavController().navigate(R.id.action_fmenuAdmin2_to_autoritzacionsAdmin)
        }

        AppRate.with(requireActivity()).setInstallDays(0).setLaunchTimes(5).setRemindInterval(1).monitor()
        //Es mostra el diàleg si es compleix alguna de les condicions
        AppRate.showRateDialogIfMeetsConditions(requireActivity())

        return binding.root
    }

    /**
     * Manejador de eventos para selección de opciones del menú.
     * @param item El elemento del menú seleccionado.
     * @return true si se manejó el evento, false en caso contrario.
     */
    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.configuracio -> {
            //binding.navHostFragmentContentMainAdmin.findNavController()
            val action = FmenuAdminDirections.actionFmenuAdmin2ToConfiguracioAdministrador()
            findNavController().navigate(action)
            true
        }
        else -> {
            // If we got here, the user's action was not recognized.
            // Invoke the superclass to handle it.
            super.onOptionsItemSelected(item)
        }
    }
}