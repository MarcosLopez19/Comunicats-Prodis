package cat.copernic.comunicatsprodis.rvParticipantsGrup

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.comunicatsprodis.databinding.ItemParticipantsGrupBinding
import cat.copernic.comunicatsprodis.rvParticipantsGrup.ProviderParticipantsGrup.Companion.missatgeListParticipantsGrup
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

/**
* Clase AdapteerParticipantsGrup encargada de mostrar los participantes de un grupo específico en un RecyclerView.
* @property missatge Lista de objetos MissatgeParticiantsGrup que contienen los datos de los participantes del grupo.
* @property messageeee String que contiene el nombre del grupo.
* @property bd Una instancia de FirebaseFirestore para realizar operaciones en la base de datos.
* @property context Contexto de la aplicación.
* @property mensaje2 Almacena el nombre del grupo.
 */
class AdapteerParticipantsGrup(private val missatge: MutableList<MissatgeParticiantsGrup>, messageeee: String) : RecyclerView.Adapter<AdapteerParticipantsGrup.ViewHolderAdminPG>() {

    private var bd = FirebaseFirestore.getInstance()
    var context: Context? = null
    val mensaje2 = messageeee

    /**
    * Clase interna que representa un ViewHolder para el diseño del elemento de participante de un grupo.
    * @param binding La vinculación para el diseño del elemento de participante de un grupo.
     */
    inner class ViewHolderAdminPG(val binding: ItemParticipantsGrupBinding): RecyclerView.ViewHolder(binding.root)

    /**
    * Crea y devuelve un nuevo ViewHolder para la vista de participantes de un grupo.
    * @param parent La vista padre donde se agregará el nuevo ViewHolder.
    * @param viewType El tipo de vista.
    * @return Una nueva instancia de ViewHolderAdminPG.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderAdminPG {
        val binding = ItemParticipantsGrupBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolderAdminPG(binding)
    }

    /**
    * Enlaza un ViewHolder con una posición específica en la lista de participantes de un grupo.
    * @param holder El ViewHolder a enlazar.
    * @param position La posición en la lista de participantes.
     */
    override fun onBindViewHolder(holder: ViewHolderAdminPG, position: Int) {
        with(holder) {
            with(missatgeListParticipantsGrup[position]) {
                binding.tvNomUsuariPG.text = this.nom
                binding.tvEmailPG.text = this.email
            }
            val nombre = binding.tvNomUsuariPG.text.toString()

            binding.imgButtonPapeleraPG.setOnClickListener {

                GlobalScope.launch {
                    bd.collection("Grups").document(mensaje2).collection("Usuaris").get().addOnSuccessListener { documents ->
                        for (document in documents) {
                            if (binding.tvNomUsuariPG.text == document.id){
                                borrarUsuario(nombre)

                            }
                        }
                    }
                }
                missatge.removeAt(position)
                notifyItemRemoved(position)
            }
        }
    }
    /**
     * Función encargada de obtener la cantidad de elementos en la lista de mensajes.
     * @return un entero que representa la cantidad de elementos en la lista de mensajes.
     */
    override fun getItemCount(): Int = missatge.size

    /**
    * Elimina un usuario de un grupo específico en la base de datos.
    * @param nom El nombre del usuario a eliminar.
     */
    fun borrarUsuario(nom: String) {
        bd.collection("Grups").document(mensaje2).collection("Usuaris").get().addOnSuccessListener { documents ->
            for (document in documents) {
                bd.collection("Grups").document(mensaje2).collection("Usuaris").document(nom).delete()
            }
        }
    }
}