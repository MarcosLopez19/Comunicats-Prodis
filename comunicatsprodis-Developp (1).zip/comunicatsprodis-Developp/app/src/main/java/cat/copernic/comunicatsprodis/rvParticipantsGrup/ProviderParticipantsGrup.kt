package cat.copernic.comunicatsprodis.rvParticipantsGrup

/**
 * Clase proveedora de la lista de participantes de un grupo.
 * @property missatgeListParticipantsGrup La lista de participantes de un grupo.
 * @constructor Crea una nueva instancia de la clase ProviderParticipantsGrup.
 */
class ProviderParticipantsGrup {
    companion object {
        val missatgeListParticipantsGrup = ArrayList<MissatgeParticiantsGrup>()
    }
}