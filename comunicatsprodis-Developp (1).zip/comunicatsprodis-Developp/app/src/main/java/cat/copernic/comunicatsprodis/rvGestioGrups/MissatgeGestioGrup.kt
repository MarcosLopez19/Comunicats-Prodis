package cat.copernic.comunicatsprodis.rvGestioGrups

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MissatgeGestioGrup(
    var nomGrup: String
): Parcelable
