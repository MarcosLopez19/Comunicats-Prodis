package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.SpinnerAdapter
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.FragmentCrearCircularBinding
import cat.copernic.comunicatsprodis.model.Circular

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext


/**
 * Clase que maneja la creación de circulares en el sistema.
 */
class crear_circular : Fragment() {
    private var _binding: FragmentCrearCircularBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        _binding = FragmentCrearCircularBinding.inflate(inflater, container, false)

        binding.crearCircularButtonEnviar.setOnClickListener {
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    comprovaRepetida()
                }
            }
        }
        binding.crearCircularButtonCancelar.setOnClickListener() {
            val action =
                crear_circularDirections.actionCrearCircularToCircularsAdministradors()
            findNavController().navigate(action)
        }
        return binding.root
    }
    /**
     * Método que se encarga de leer los datos introducidos por el usuario en los campos de texto correspondientes
     * a nombre de circular, contenido y destinatarios y devolver un objeto de tipo Circular con esos datos.
     * @return objeto Circular con los datos introducidos por el usuario
     */
    fun llegirDades(): Circular {
        //Guardem les dades introduïdes per l'usuari
        var nomCircular = binding.crearCircularTextInputEditTextNomCiuclar.text.toString()
        var contringut = binding.crearCircularTextInputtext2.text.toString()
        var destinataris = binding.crearCircularTextInputEditTextDestinataris.text.toString()
        return Circular(nomCircular, contringut, destinataris)
    }
    /**
     * Método que se encarga de añadir una circular en la base de datos. Se añade una subcolección en la colección
     * de Circulares con el nombre del objeto Circular y se establecen los listeners para el caso de éxito
     * y fracaso en la operación.
     * @param circulars objeto Circular que se va a añadir en la base de datos
     */
    fun afegirCircular(circulars: Circular) {

        //Afegim una subcolecció igual que afegim una col.lecció però penjant de la col.lecció on està inclosa.
        bd.collection("Circulars").document(circulars.nomCircular).set(circulars)
            .addOnSuccessListener {
                //S'ha afegit el departament...
                val builder = AlertDialog.Builder(requireContext())
                builder.setMessage(getString(R.string.alertDialog_messageCircular))
                builder.setPositiveButton(getString(R.string.Aceptar_AlertDialogError), null)
                val dialog = builder.create()
                dialog.show()

            }
            .addOnFailureListener { //No s'ha afegit el departament...
                val builder = AlertDialog.Builder(requireContext())
                builder.setMessage(getString(R.string.error_la_Circulat_no_ha_afegit))
                builder.setPositiveButton(getString(R.string.Aceptar_AlertDialogError), null)
                val dialog = builder.create()
                dialog.show()
            }
    }

    /**
     * Método suspendido que se encarga de comprobar si existe alguna circular con el mismo nombre que la que se
     * quiere añadir en la base de datos, si no existe se añade y se comprueba los destinatarios,
     * si esta todoo correcto se redirige a la pantalla de administrador de Circulares.
     */
    suspend fun comprovaRepetida() {

        //comprobar si existe alguna circular con el mismo nombre
        lifecycleScope.launch {
            var circulars = llegirDades()
            var count = 0
            val result =
                bd.collection("Circulars").get().await()

            if (!result.isEmpty) {
                for (document in result) {
                    if (circulars.nomCircular == document["nomCircular"].toString()) {
                        count++
                    }
                }
            }
            if (circulars.nomCircular.isNotEmpty() && count == 0) {
                if(comprovaDestinatari(llegirDades())){
                    afegirCircular(circulars)
                    val action =
                        crear_circularDirections.actionCrearCircularToCircularsAdministradors()
                    findNavController().navigate(action)
                        Utils.notification(llegirDades().nomCircular, "Circualr", requireContext())
                }else{
                    binding.crearCircularTextInputEditTextDestinataris.error = getString(R.string.Destinatari)
                }
            } else {
                binding.crearCircularTextInputEditTextNomCiuclar.error=getString(R.string.errorjaHiaHaUnaCircularAmbMateixNom)
            }
        }
    }

    /**
     * Método suspendido que se encarga de comprobar si existe el destinatario que se quiere añadir en una circular,
     * se busca en la base de datos en la colección de "Grupos" si existe un grupo con ese nombre.
     * @param circular objeto Circular que se va a comprobar si existe destinatario
     * @return si existe o no el destinatario
     */
    suspend fun comprovaDestinatari(circular: Circular): Boolean {
        var existe = false
        val query =
            bd.collection("Grups").get()
                .await()
        for (document in query) {
            if (document["nomgrup"].toString() == circular.Destinataris) {
                existe = true
            }
        }
        return existe
    }


}