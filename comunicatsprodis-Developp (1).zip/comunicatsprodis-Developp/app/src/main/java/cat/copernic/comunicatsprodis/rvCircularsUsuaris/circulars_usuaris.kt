package cat.copernic.comunicatsprodis.rvCircularsUsuaris

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.comunicatsprodis.databinding.FragmentCircularsUsuarisBinding
import cat.copernic.comunicatsprodis.rvCircularsUsuaris.adapter.CircularsAdapter
import cat.copernic.comunicatsprodis.R
import cat.copernic.comunicatsprodis.Utils
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * Clase fragmento para la gestión de circulares por parte del usuario.
 * Utiliza un RecyclerView para mostrar la lista de circulares existentes y permite añadir nuevas circulares.
 */
class circulars_usuaris : Fragment() {

    private var _binding: FragmentCircularsUsuarisBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()
    private var param1: String? = null
    private var param2: String? = null
    private val utils = Utils()


    /**
     * Sobreescribe el método onCreate de la clase Activity.
     * Se ejecuta al crear la vista, se utiliza para inicializar variables y establecer la configuración de la vista.
     * @param savedInstanceState, un objeto Bundle que contiene el estado anterior de la actividad si fue destruida.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CircularsProvider.CircularsList
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de circulares de administrador.
     */
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?

    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentCircularsUsuarisBinding.inflate(inflater)
        return binding.root

    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerView()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment circulars_usuaris.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            circulars_usuaris().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
    /**
     * Inicializa el RecyclerView con los datos de las circulares existentes en la base de datos.
     */
    private fun initRecyclerView() {
        CircularsProvider.CircularsList.clear()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                rellenarCircularsProvider()
            }
        }

    }
    /**
     * Se encarga de obtener los datos de las circulares existentes en la base de datos y añadirlos a la lista de circulares.
     */
    suspend fun rellenarCircularsProvider() {

        // Inicia una operación en el "lifecycle scope" de la aplicación
        lifecycleScope.launch {
            // Realiza una consulta a la colección "Circulars" en la base de datos
            var resultatConsulta = bd.collection("Circulars").get().await()
            // Si la consulta no está vacía
            if (!resultatConsulta.isEmpty) {
                // Recorre cada documento en la consulta
                for (document in resultatConsulta) {
                    // Contador para verificar si el nombre del documento ya existe en la lista
                    var count = 0

                    // Crea un objeto "wallItem" de tipo "Circulars" con los datos del documento
                    val wallItem = Circulars(
                        nombreCircular = document.id,
                        contenido = document["contingut"].toString(),
                        img = R.drawable.foto_perfil
                    )

                    // Realiza otra consulta a la base de datos, en la subcolección "Usuaris" del documento en la colección "Grups" con el ID del documento "Circulars"
                    var countEstaUsuari = 0
                    val query = bd.collection("Grups")
                        .document(document["destinataris"].toString())
                        .collection("Usuaris")
                        .get()
                        .await()
                    // Recorre cada documento en la subcolección "Usuaris"
                    for (document2 in query) {
                        // Obtiene el valor del campo "Gmail tutor1" del documento
                        val query3 = document2["Gmail tutor1"].toString()
                        // Si el valor es igual al correo del usuario actual
                        if (query3 == utils.getCorreoUserActural()) {
                            // Incrementa el contador
                            countEstaUsuari++
                        }
                    }
                    // Si la lista "CircularsList" está vacía y el usuario está en el grupo
                    if (CircularsProvider.CircularsList.isEmpty() && countEstaUsuari != 0) {
                        // Añade el objeto "wallItem" a la lista
                        CircularsProvider.CircularsList.add(wallItem)
                        // Si la lista no está vacía y el usuario está en el grupo
                    } else if (countEstaUsuari != 0) {
                        // Recorre la lista "CircularsList"
                        for (i in CircularsProvider.CircularsList) {
                            // Si el nombre del documento ya existe en la lista
                            if (wallItem.nombreCircular == i.nombreCircular) {
                                // Incrementa el contador
                                count++
                            }
                        }
                        if (count == 0) {
                            CircularsProvider.CircularsList.add(wallItem)
                        }
                    }
                }
            }
            binding.recyclerCircularsUsuaris.layoutManager = LinearLayoutManager(context)
            binding.recyclerCircularsUsuaris.adapter =
                CircularsAdapter(CircularsProvider.CircularsList.toList())
        }
    }


}

