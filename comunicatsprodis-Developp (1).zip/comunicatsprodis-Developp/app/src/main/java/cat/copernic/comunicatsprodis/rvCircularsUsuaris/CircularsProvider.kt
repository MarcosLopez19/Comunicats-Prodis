package cat.copernic.comunicatsprodis.rvCircularsUsuaris

import cat.copernic.comunicatsprodis.rvCircularsAdmin.CircularsAdminProvider.Companion.CircularsAdminList


/**
 * Clase que provee una lista de Circualrs
 * @property Circulars lista de Ciculars
 * @constructor Crea una nueva instancia de la clase Provider.
 */
class CircularsProvider {

    companion object{

        val CircularsList= ArrayList<Circulars>(

        )


    }
}