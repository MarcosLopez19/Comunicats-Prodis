package cat.copernic.comunicatsprodis

import android.Manifest.permission.INTERNET
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import cat.copernic.comunicatsprodis.model.Autoritzacio
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.tasks.await
import java.util.Objects
import java.util.regex.Pattern

/**
 * Clase en la cual hay varias funciones, las cuales se repetian varias veces y por lo tanto hemos decidio añadirlas
 * en este fichero y cuando las necesitemos, las llamamos.
 */
class Utils {
    private var bd = FirebaseFirestore.getInstance()
    private lateinit var auth: FirebaseAuth

    /**
     * Obtiene el correo electrónico del usuario actualmente autenticado en Firebase.
     * @return El correo electrónico del usuario autenticado en Firebase como una cadena.
     */
    fun getCorreoUserActural(): String {
        auth = Firebase.auth
        val currentUser = auth.currentUser
        return currentUser!!.email.toString()
    }

    companion object {
        private lateinit var auth: FirebaseAuth

        /**
         * Crea una notificación en el dispositivo del usuario
         * @param nom Nombre del objeto asociado a la notificación
         * @param tipo Tipo de objeto asociado a la notificación
         * @param context Contexto de la aplicación en el momento de la notificación
         */
        fun notification(nom: String, tipo: String, context: Context) {
            val notification = NotificationCompat.Builder(context,"1").also{ noti ->
                noti.setContentTitle("$tipo creada")
                noti.setContentText("S'ha creat l' $tipo $nom")
                noti.setSmallIcon(R.drawable.comunicats_prodis)
            }.build()
            val notificationManageer = NotificationManagerCompat.from(context)
            notificationManageer.notify(1,notification)
        }

        /**
         * Obtiene el correo electrónico del usuario actualmente autenticado en Firebase.
         * @return El correo electrónico del usuario autenticado en Firebase como una cadena.
         */
        fun getCorreoUserActural(): String {
            auth = Firebase.auth
            val currentUser = auth.currentUser
            return currentUser!!.email.toString()
        }
    }

    /**
     * Esta función valida que una dirección de correo electrónico sea válida.
     * @param email La dirección de correo electrónico a validar.
     * @return true si el correo es válido, false si no lo es.
    */
    fun isValidEmail(email: String): Boolean {
        val pattern = Pattern.compile(
            "^([\\w]*[\\w\\.]*(?!\\.)@gmail.com)"
        )
        val matcher = pattern.matcher(email)
        return matcher.matches()
    }

    /**
     * Esta función valida que un número de telefono sea válido.
     * @param phoneNumber El número de telefono a validar.
     * @return true si el número es válido, false si no lo es.
     */
    fun isValidPhoneNumber(phoneNumber: String): Boolean {
        val pattern = Pattern.compile("^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\\s\\./0-9]*\$")
        val matcher = pattern.matcher(phoneNumber)
        return matcher.matches()
    }
    //validar con regex la calle
    fun isValidStreetAddress(streetAddress: String): Boolean {
        val pattern = Pattern.compile("^[a-zA-Z0-9\\s,'-]*\$")
        val matcher = pattern.matcher(streetAddress)
        return matcher.matches()
    }
    /**
     * Esta función valida que es un nombre y no contiene numeros ni simbolos.
     * @param string El nombre a validar.
     * @return true si el nombre es válido, false si no lo es.
     */
    fun isAlpha(string: String): Boolean {
        val pattern = Pattern.compile("^[a-zA-Z]*\$")
        val matcher = pattern.matcher(string)
        return matcher.matches()
    }
}