package cat.copernic.comunicatsprodis

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.comunicatsprodis.databinding.FragmentAutoritzacionsAdminBinding
import cat.copernic.comunicatsprodis.rvAutorizacions.admin.AdapterAutoritzacionsAdmin
import cat.copernic.comunicatsprodis.rvAutorizacions.admin.provider
import cat.copernic.comunicatsprodis.rvAutorizacions.admin.MissatgeAdmin
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * Clase fragmento para la gestión de autorizaciones por parte del administrador.
 * Utiliza un RecyclerView para mostrar la lista de autorizaciones existentes y permite añadir nuevas autorizaciones.
 */
class autoritzacionsAdmin : Fragment() {

    private var _binding: FragmentAutoritzacionsAdminBinding? = null
    private val binding get() = _binding!!
    val bd = FirebaseFirestore.getInstance()

    /**
     * Sobreescribe el método onCreate de la clase Activity.
     * Se ejecuta al crear la vista, se utiliza para inicializar variables y establecer la configuración de la vista.
     * @param savedInstanceState, un objeto Bundle que contiene el estado anterior de la actividad si fue destruida.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        provider.missatgeList
    }

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autorizaciones de administrador.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentAutoritzacionsAdminBinding.inflate(inflater)
        return binding.root
    }

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.actionButtonCrate.setOnClickListener {
            val action = autoritzacionsAdminDirections.actionAutoritzacionsAdminToCrearAutoritzacio()
            findNavController().navigate(action)
        }
        configSwipeAuto()
        initRecylceView()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment autoritzacionsAdmin.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            autoritzacionsAdmin().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    /**
     * Inicializa el RecyclerView con los datos de las autorizaciones existentes en la base de datos.
     */
    private fun initRecylceView() {
        provider.missatgeList.clear()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                llamarRecyclerView()
            }
        }
    }

    /**
     * Se encarga de obtener los datos de las autorizaciones existentes en la base de datos y añadirlos a la lista de autorizaciones.
     */
    suspend fun llamarRecyclerView() {

        lifecycleScope.launch {
            // Obtiene una QuerySnapshot con todos los documentos de la colección "Autoritzacions" de la base de datos
            var resultat = bd.collection("Autoritzacions").get().await()

            if (!resultat.isEmpty) {
                // Itera sobre cada documento en el resultado
                for (document in resultat) {
                        var count=0
                    // Crea un nuevo objeto MissatgeAdmin con algunos datos del documento
                        val wallItem = MissatgeAdmin(
                            nomMissatge = document.id,
                            missatge = document["contingut"].toString(),
                            descripcio = document["descripcio"].toString(),
                            destinataris = document["destinataris"].toString()
                        )
                    // Si la lista missatgeList está vacía, añade el nuevo objeto a la lista
                        if (provider.missatgeList.isEmpty()) {
                            provider.missatgeList.add(wallItem)
                        } else {
                            // Si la lista no está vacía, comprueba si hay un elemento con el mismo nombre en la lista
                            for (i in provider.missatgeList) {
                                if (wallItem.nomMissatge == i.nomMissatge) {
                                    count++
                                }
                            }
                            // Si no hay un elemento con el mismo nombre, añade el nuevo objeto a la lista
                            if (count == 0) {
                                provider.missatgeList.add(wallItem)
                            }
                        }
                    }
                // Establece un LinearLayoutManager para el RecyclerView y un AdapterAutoritzacionsAdmin como adaptador
                // del RecyclerView, pasando la lista de CircularsAdmin como parámetro
                binding.autoritzacionsAdminRecycleView.layoutManager = LinearLayoutManager(context)
                binding.autoritzacionsAdminRecycleView.adapter =
                    AdapterAutoritzacionsAdmin(provider.missatgeList.toMutableList())
            }
        }
    }
    // Configura el listener del gesto de deslizar hacia abajo para actualizar la lista
    /**
    * Configura el swipe refresh en la vista de autorizaciones del administrador.
    * Crea un retraso de 1 segundo antes de actualizar la lista, limpia la lista de CircularesAdmin,
    * lanza una corrutina para rellenar la lista en un hilo de background y oculta la barra de progreso de actualización.
     */
    fun configSwipeAuto(){
        // Crea un retraso de 1 segundo antes de actualizar la lista
        binding.swipeAutorizacionsAdmin.setOnRefreshListener {
            Handler(Looper.getMainLooper()).postDelayed({
                // Limpia la lista de CircularsAdmin
                provider.missatgeList.clear()
                // Lanza una corrutina para rellenar la lista en un hilo de background
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        llamarRecyclerView()
                    }
                }
                // Oculta la barra de progreso de actualización
                binding.swipeAutorizacionsAdmin.isRefreshing = false
            },1000)

        }
    }
}