package cat.copernic.comunicatsprodis.rvAutorizacions.admin

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
* Clase que representa un mensaje de administrador.
* @property nomMissatge nombre del mensaje
* @property missatge el contenido del mensaje
* @property descripcio una descripción adicional del mensaje
* @property destinataris los destinatarios del mensaje
* @constructor Crea una nueva instancia de MissatgeAdmin con los parámetros especificados.
* @Implements [Parcelable] para permitir la serialización y deserialización de esta clase.
 */
@Parcelize
data class MissatgeAdmin (
    val nomMissatge:String,
    val missatge:String,
    val descripcio: String,
    val destinataris: String
): Parcelable