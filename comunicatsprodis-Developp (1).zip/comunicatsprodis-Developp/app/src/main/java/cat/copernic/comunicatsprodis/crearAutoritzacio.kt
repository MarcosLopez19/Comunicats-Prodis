package cat.copernic.comunicatsprodis

import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.FragmentCrearAutoritzacioBinding
import cat.copernic.comunicatsprodis.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * Clase que maneja la creación de autorizaciones en el sistema.
 */
class crearAutoritzacio : Fragment() {

    private var _binding: FragmentCrearAutoritzacioBinding? = null
    private val binding get() = _binding!!
    private var bd = FirebaseFirestore.getInstance()
    private var auth: FirebaseAuth? = null

    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    /**
     * Se llama después de que la vista del fragmento ha sido creada.
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = Firebase.auth

        binding.crearAutoritzacioAceptar.setOnClickListener {
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    comprovaAutoritzacio()
                }
            }
        }
        binding.crearAutoritzacioCancelar.setOnClickListener {
            var action = crearAutoritzacioDirections.actionCrearAutoritzacioToAutoritzacionsAdmin()
            findNavController().navigate(action)
        }
    }

    /**
     * Crea y devuelve la vista del fragmento de autorizaciones de administrador.
     * @param inflater El inflador de layout utilizado para inflar la vista.
     * @param container El contenedor padre de la vista.
     * @param savedInstanceState El estado previamente guardado del fragmento.
     * @return La vista del fragmento de autoritzacionsUsuari.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        _binding = FragmentCrearAutoritzacioBinding.inflate(inflater, container, false)
        return binding.root
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment crearAutoritzacio.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            crearAutoritzacio().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    /**
     * Método para leer los datos introducidos por el usuario y guardarlos en una nueva instancia de la clase Autoritzacio.
     * @return una nueva instancia de Autoritzacio con los datos introducidos por el usuario.
     */
    fun llegirDades(): Autoritzacio {
        //Guardem les dades introduïdes per l'usuari
        var nom = binding.crearAutoritzacioNomAutoritzacio.text.toString()
        var descripcio = binding.crearAutoritzacioDescripcio.text.toString()
        var contingut = binding.crearAutoritzacioText.text.toString()
        var destinataris = binding.crearAutoritzacioDestinataris.text.toString()

        return Autoritzacio(nom, descripcio, contingut, /*grups, */null, destinataris)
    }

    /**
     * Añade una nueva autorización a la base de datos.
     * @param autoritzacio la autorización a añadir a la base de datos.
     */
    fun afegirAutoritzacio(autoritzacio: Autoritzacio) {

        bd.collection("Autoritzacions").document(autoritzacio.nom).set(autoritzacio)
            .addOnSuccessListener {
                val builder = AlertDialog.Builder(requireContext())
                builder.setMessage(getString(R.string.Autoritzacio_afegida))
                builder.setPositiveButton(getString(R.string.aceptar), null)
                val dialog = builder.create()
                dialog.show()
            }
            .addOnFailureListener { //No s'ha afegit el departament...
                val builder = AlertDialog.Builder(requireContext())
                builder.setMessage(getString(R.string.Autoritzacio_noAfegida))
                builder.setPositiveButton(R.string.aceptar, null)
                val dialog = builder.create()
                dialog.show()
            }
    }

    /**
     * Comprueba que no haya ninguna autorización ya creada con el mismo nombre y que el grupo escrito en destinatarios exista.
     * Si todoo es correcto, añade la autorización a la base de datos, navega a la página de autorizaciones para administradores
     * y envía una notificación con el nombre de la autorización creada.
     */
    suspend fun comprovaAutoritzacio() {

        lifecycleScope.launch {
            var autoritzacio = llegirDades()
            var count = 0
            val result = bd.collection("Autoritzacions").get().await()

            if (!result.isEmpty)
                for (document in result)
                    if (autoritzacio.nom == document.id)
                        count++

            if (autoritzacio.nom.isNotEmpty() && count == 0) {
                if (comprovaDestinatari(llegirDades())) {
                    afegirAutoritzacio(autoritzacio)
                    val action = crearAutoritzacioDirections.actionCrearAutoritzacioToAutoritzacionsAdmin()
                    findNavController().navigate(action)
                    Utils.notification(llegirDades().nom, "Autoritzacio", requireContext())
                } else {
                    binding.crearAutoritzacioDestinataris.error = getString(R.string.Destinatari)
                }
            } else {
                binding.crearAutoritzacioNomAutoritzacio.error = getString(R.string.AutoritzacioRepetida)
            }
        }
    }

    /**
     * Mediante esta función comprobamos que exista algun grupo con el nombre que inscribe el usuario
     */
    suspend fun comprovaDestinatari(autoritzacio: Autoritzacio): Boolean {
        var existe = false
        val query = bd.collection("Grups").get().await()

        for (document in query)
            if (document["nomgrup"].toString() == autoritzacio.Destinataris)
                existe = true

        return existe
    }
}


