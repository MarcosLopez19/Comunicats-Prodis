package cat.copernic.comunicatsprodis

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import cat.copernic.comunicatsprodis.databinding.FragmentFmenuBinding
import hotchemi.android.rate.AppRate

/**
 * Clase que representa el menú principal de la aplicación.
 */
class Fmenu : Fragment() {

    private var _binding: FragmentFmenuBinding? = null
    private val binding get() = _binding!!

    /**
     * Método que se encarga de crear y devolver la vista asociada a esta clase.
     * @param inflater objeto LayoutInflater que permite inflar la vista.
     * @param container contenedor donde se va a colocar la vista.
     * @param savedInstanceState estado guardado de la instancia.
     * @return la vista creada.
     */
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentFmenuBinding.inflate(inflater, container, false)
        binding.btnImgCiruclars.setOnClickListener() {
            findNavController().navigate(R.id.action_fmenu_to_circulars_usuaris)
        }
        binding.btnImgAutorizacions.setOnClickListener() {
            //findNavController().navigate(R.id.action_fmenu_to_autoritzacionsUsuari)
            findNavController().navigate(R.id.action_fmenu_to_autoritzacionsUsuari)
        }
        AppRate.with(requireActivity()).setInstallDays(0).setLaunchTimes(2).setRemindInterval(1).monitor()
        //Es mostra el diàleg si es compleix alguna de les condicions
        AppRate.showRateDialogIfMeetsConditions(requireActivity())

        return binding.root
    }
}