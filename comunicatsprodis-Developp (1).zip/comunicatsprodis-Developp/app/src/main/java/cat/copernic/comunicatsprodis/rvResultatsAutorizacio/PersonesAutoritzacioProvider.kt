package cat.copernic.comunicatsprodis.rvResultatsAutorizacio

import cat.copernic.comunicatsprodis.rvResultatsAutorizacio.PersonesAutoritzacio

class PersonesAutoritzacioProvider {
    companion object{
        val personesListsi = listOf<PersonesAutoritzacio>(

            PersonesAutoritzacio(
                "Ramon"
            ),

            PersonesAutoritzacio(
                "Pablo"
            ),

            PersonesAutoritzacio(
                "Marcos"
            )
        )

        val personesListno = listOf<PersonesAutoritzacio>(

            PersonesAutoritzacio(
                "Marcos"
            ),

            PersonesAutoritzacio(
                "Pablo"
            ),

            PersonesAutoritzacio(
                "Ramon"
            )
        )
    }
}